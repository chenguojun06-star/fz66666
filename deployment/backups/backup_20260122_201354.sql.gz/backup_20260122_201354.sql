-- MySQL dump 10.13  Distrib 8.0.44, for Linux (aarch64)
--
-- Host: localhost    Database: fashion_supplychain
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_cutting_bundle`
--

DROP TABLE IF EXISTS `t_cutting_bundle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_cutting_bundle` (
  `id` varchar(36) NOT NULL COMMENT 'æ‰Žå·ID',
  `production_order_id` varchar(36) NOT NULL COMMENT 'ç”Ÿäº§è®¢å•ID',
  `production_order_no` varchar(50) NOT NULL COMMENT 'ç”Ÿäº§è®¢å•å·',
  `style_id` varchar(36) NOT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) NOT NULL COMMENT 'æ¬¾å·',
  `color` varchar(50) DEFAULT NULL COMMENT 'é¢œè‰²',
  `size` varchar(50) DEFAULT NULL COMMENT 'ç æ•°',
  `bundle_no` int NOT NULL COMMENT 'æ‰Žå·åºå·',
  `quantity` int NOT NULL DEFAULT '0' COMMENT 'æ•°é‡',
  `qr_code` varchar(200) NOT NULL COMMENT 'äºŒç»´ç å†…å®¹',
  `status` varchar(20) DEFAULT 'created' COMMENT 'çŠ¶æ€',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `qr_code` (`qr_code`),
  KEY `idx_order_id` (`production_order_id`),
  KEY `idx_order_no` (`production_order_no`),
  KEY `idx_style_no` (`style_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='è£å‰ªæ‰Žå·è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cutting_bundle`
--

LOCK TABLES `t_cutting_bundle` WRITE;
/*!40000 ALTER TABLE `t_cutting_bundle` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cutting_bundle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cutting_task`
--

DROP TABLE IF EXISTS `t_cutting_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_cutting_task` (
  `id` varchar(36) NOT NULL COMMENT '裁剪任务ID',
  `production_order_id` varchar(36) NOT NULL COMMENT '生产订单ID',
  `production_order_no` varchar(50) NOT NULL COMMENT '生产订单号',
  `order_qr_code` varchar(100) DEFAULT NULL COMMENT '订单二维码内容',
  `style_id` varchar(36) NOT NULL COMMENT '款号ID',
  `style_no` varchar(50) NOT NULL COMMENT '款号',
  `style_name` varchar(100) DEFAULT NULL COMMENT '款名',
  `color` varchar(50) DEFAULT NULL COMMENT '颜色',
  `size` varchar(50) DEFAULT NULL COMMENT '码数',
  `order_quantity` int DEFAULT '0' COMMENT '订单数量',
  `status` varchar(20) DEFAULT 'pending' COMMENT '状态',
  `receiver_id` varchar(36) DEFAULT NULL COMMENT '领取人ID',
  `receiver_name` varchar(50) DEFAULT NULL COMMENT '领取人',
  `received_time` datetime DEFAULT NULL COMMENT '领取时间',
  `bundled_time` datetime DEFAULT NULL COMMENT '生成裁剪单时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_id` (`production_order_id`),
  KEY `idx_order_no` (`production_order_no`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='裁剪任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cutting_task`
--

LOCK TABLES `t_cutting_task` WRITE;
/*!40000 ALTER TABLE `t_cutting_task` DISABLE KEYS */;
INSERT INTO `t_cutting_task` VALUES ('d7c38b023db4efb9af749c149a44ab4d','0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','PO20260122001','4','ST2026012200111','衬衫','格子灰色','S,M,L,XL,XXL',50,'received','1','系统管理员','2026-01-22 19:31:12',NULL,'2026-01-22 14:48:53','2026-01-22 19:31:12');
/*!40000 ALTER TABLE `t_cutting_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_deduction_item`
--

DROP TABLE IF EXISTS `t_deduction_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_deduction_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ‰£æ¬¾é¡¹ID',
  `reconciliation_id` bigint NOT NULL COMMENT 'å¯¹è´¦å•ID',
  `deduction_type` varchar(50) NOT NULL COMMENT 'æ‰£æ¬¾ç±»åž‹',
  `deduction_amount` decimal(10,2) NOT NULL COMMENT 'æ‰£æ¬¾é‡‘é¢',
  `description` varchar(200) DEFAULT NULL COMMENT 'æ‰£æ¬¾æè¿°',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_reconciliation_id` (`reconciliation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='åŠ å·¥åŽ‚æ‰£æ¬¾é¡¹è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_deduction_item`
--

LOCK TABLES `t_deduction_item` WRITE;
/*!40000 ALTER TABLE `t_deduction_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_deduction_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'å­—å…¸ID',
  `dict_code` varchar(50) NOT NULL COMMENT 'å­—å…¸ç¼–ç ',
  `dict_label` varchar(100) NOT NULL COMMENT 'å­—å…¸æ ‡ç­¾',
  `dict_value` varchar(100) NOT NULL COMMENT 'å­—å…¸å€¼',
  `dict_type` varchar(50) NOT NULL COMMENT 'å­—å…¸ç±»åž‹',
  `sort` int DEFAULT '0' COMMENT 'æŽ’åº',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_dict_type` (`dict_type`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å­—å…¸è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
INSERT INTO `t_dict` VALUES (1,'WOMAN','å¥³è£…','WOMAN','category',1,'ENABLED','2026-01-22 02:41:47','2026-01-22 02:41:47'),(2,'MAN','ç”·è£…','MAN','category',2,'ENABLED','2026-01-22 02:41:47','2026-01-22 02:41:47'),(3,'KID','ç«¥è£…','KID','category',3,'ENABLED','2026-01-22 02:41:47','2026-01-22 02:41:47'),(4,'SPRING','春季','SPRING','season',1,'ENABLED','2026-01-22 02:41:47','2026-01-22 03:43:06'),(5,'SUMMER','夏季','SUMMER','season',2,'ENABLED','2026-01-22 02:41:47','2026-01-22 03:43:06'),(6,'AUTUMN','秋季','AUTUMN','season',3,'ENABLED','2026-01-22 02:41:47','2026-01-22 03:43:06'),(7,'WINTER','冬季','WINTER','season',4,'ENABLED','2026-01-22 02:41:47','2026-01-22 03:43:06');
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_factory`
--

DROP TABLE IF EXISTS `t_factory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_factory` (
  `id` varchar(36) NOT NULL,
  `factory_code` varchar(50) NOT NULL COMMENT 'å·¥åŽ‚ç¼–ç ',
  `factory_name` varchar(100) NOT NULL COMMENT 'å·¥åŽ‚åç§°',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT 'è”ç³»ç”µè¯',
  `address` varchar(200) DEFAULT NULL COMMENT 'å·¥åŽ‚åœ°å€',
  `business_license` varchar(255) DEFAULT NULL COMMENT 'è¥ä¸šæ‰§ç…§å›¾ç‰‡URL',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `delete_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记: 0-未删除, 1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `factory_code` (`factory_code`),
  KEY `idx_factory_code` (`factory_code`),
  KEY `idx_factory_name` (`factory_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å·¥åŽ‚è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_factory`
--

LOCK TABLES `t_factory` WRITE;
/*!40000 ALTER TABLE `t_factory` DISABLE KEYS */;
INSERT INTO `t_factory` VALUES ('872055c6327a18338bd1c8788e4e3158','001','最美服装工厂','最美','15625150333','广州番禺',NULL,'active','2026-01-22 14:45:56','2026-01-22 14:45:56',0);
/*!40000 ALTER TABLE `t_factory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_login_log`
--

DROP TABLE IF EXISTS `t_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ—¥å¿—ID',
  `username` varchar(50) NOT NULL COMMENT 'ç”¨æˆ·å',
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'ç™»å½•æ—¶é—´',
  `login_ip` varchar(20) NOT NULL COMMENT 'ç™»å½•IP',
  `login_result` varchar(20) NOT NULL COMMENT 'ç™»å½•ç»“æžœï¼šSUCCESS-æˆåŠŸï¼ŒFAILED-å¤±è´¥',
  `error_message` varchar(200) DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  PRIMARY KEY (`id`),
  KEY `idx_login_time` (`login_time`),
  KEY `idx_username` (`username`),
  KEY `idx_login_result` (`login_result`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç™»å½•æ—¥å¿—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_login_log`
--

LOCK TABLES `t_login_log` WRITE;
/*!40000 ALTER TABLE `t_login_log` DISABLE KEYS */;
INSERT INTO `t_login_log` VALUES (1,'199711','2026-01-22 10:55:43','127.0.0.1','FAILED','用户名或密码错误'),(2,'admin','2026-01-22 10:55:51','127.0.0.1','SUCCESS','登录成功'),(3,'admin','2026-01-22 11:45:13','192.168.2.248','FAILED','用户名或密码错误'),(4,'admin','2026-01-22 11:45:20','192.168.2.248','SUCCESS','登录成功'),(5,'admin','2026-01-22 14:55:02','192.168.2.128','SUCCESS','登录成功'),(6,'admin','2026-01-22 15:03:40','127.0.0.1','SUCCESS','登录成功'),(7,'admin','2026-01-22 15:24:20','127.0.0.1','SUCCESS','登录成功'),(8,'admin','2026-01-22 15:43:37','127.0.0.1','SUCCESS','登录成功'),(9,'admin','2026-01-22 15:49:12','127.0.0.1','SUCCESS','登录成功'),(10,'admi','2026-01-22 15:57:48','127.0.0.1','FAILED','用户名或密码错误'),(11,'admin','2026-01-22 15:57:54','127.0.0.1','SUCCESS','登录成功'),(12,'admin','2026-01-22 16:05:44','127.0.0.1','SUCCESS','登录成功'),(13,'admin','2026-01-22 16:07:08','127.0.0.1','SUCCESS','登录成功'),(14,'admin','2026-01-22 16:22:23','127.0.0.1','SUCCESS','登录成功'),(15,'admin','2026-01-22 16:41:33','127.0.0.1','SUCCESS','登录成功'),(16,'admin','2026-01-22 19:14:39','192.168.2.128','SUCCESS','登录成功'),(17,'admin','2026-01-22 20:09:45','127.0.0.1','SUCCESS','登录成功');
/*!40000 ALTER TABLE `t_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_database`
--

DROP TABLE IF EXISTS `t_material_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_database` (
  `id` varchar(36) NOT NULL COMMENT '物料ID',
  `material_code` varchar(50) NOT NULL COMMENT '物料编码',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `style_no` varchar(50) DEFAULT NULL COMMENT '款号',
  `material_type` varchar(20) DEFAULT 'accessory' COMMENT '物料类型',
  `specifications` varchar(100) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `supplier_name` varchar(100) DEFAULT NULL COMMENT '供应商',
  `unit_price` decimal(10,2) DEFAULT '0.00' COMMENT '单价',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `image` varchar(500) DEFAULT NULL COMMENT '图片URL',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `status` varchar(20) DEFAULT 'pending' COMMENT '状态',
  `completed_time` datetime DEFAULT NULL COMMENT '完成时间',
  `return_reason` varchar(255) DEFAULT NULL COMMENT '退回原因',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `delete_flag` int NOT NULL DEFAULT '0' COMMENT '删除标识：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_material_code` (`material_code`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_supplier_name` (`supplier_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='面辅料数据库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_database`
--

LOCK TABLES `t_material_database` WRITE;
/*!40000 ALTER TABLE `t_material_database` DISABLE KEYS */;
INSERT INTO `t_material_database` VALUES ('24a77c931f0a8963f931063d21a6c32f','PKG-376191-09','包装袋','ST2026012200111','accessoryA','0','个','最美布行',0.20,NULL,NULL,NULL,'completed','2026-01-22 17:27:22',NULL,'2026-01-22 14:19:08','2026-01-22 17:27:22',0),('3ec71218b829df12e89c131fdc5d6081','BTN-376191-06','纽扣','ST2026012200111','accessory','1.5','颗','最美布行',0.20,NULL,NULL,NULL,'completed','2026-01-22 17:27:30',NULL,'2026-01-22 14:19:07','2026-01-22 17:27:30',0),('40b9b0c666b437482457f314d113669c','PKG-658552-09','包装袋','HYY2026012212','accessory','0','个','最美布行',0.20,NULL,NULL,NULL,'completed','2026-01-22 17:27:34',NULL,'2026-01-22 11:50:02','2026-01-22 17:27:34',0),('7e1ad00840ed89e77cc6801bdf88e5fd','LBL-658552-08','主唛/洗唛/尺码标','HYY2026012212','accessory','0','套','最美布行',0.50,NULL,NULL,NULL,'completed','2026-01-22 17:27:37',NULL,'2026-01-22 11:50:02','2026-01-22 17:27:37',0),('8454c19759dfec8f78b296cccf7fd209','INT-658552-04','衬布/粘合衬','HYY2026012212','lining','112','米','最美布行',5.00,NULL,NULL,NULL,'completed','2026-01-22 17:27:41',NULL,'2026-01-22 11:50:02','2026-01-22 17:27:41',0),('96d14b2a62493fc2d688c5f4ae1839e4','INT-376191-04','衬布/粘合衬','ST2026012200111','lining','112','米','最美布行',7.00,NULL,NULL,NULL,'completed','2026-01-22 17:27:27',NULL,'2026-01-22 14:19:07','2026-01-22 17:27:27',0),('99515795d941b2913e2fce78aec3f9fa','BTN-658552-06','纽扣','HYY2026012212','accessory','1.5','颗','最美布行',2.00,NULL,NULL,NULL,'completed','2026-01-22 17:27:52',NULL,'2026-01-22 11:50:02','2026-01-22 17:27:52',0),('9f1e3338fabab9d612ddcf85dd629c99','FAB-376191-01','主面料','ST2026012200111','fabric','150','米','最美布行',15.00,NULL,NULL,NULL,'completed','2026-01-22 17:27:47',NULL,'2026-01-22 14:19:07','2026-01-22 17:27:47',0),('a197a1886958ca571a44e79c39ad94c3','LBL-376191-08','主唛/洗唛/尺码标','ST2026012200111','accessoryA','0','套','最美布行',0.50,NULL,NULL,NULL,'completed','2026-01-22 17:27:17',NULL,'2026-01-22 14:19:08','2026-01-22 17:27:17',0),('bb59d661e72d9a4eab212b007a87ff23','FAB-658552-01','主面料','HYY2026012212','fabric','150','米','最美布行',18.00,NULL,NULL,NULL,'completed','2026-01-22 17:27:56',NULL,'2026-01-22 11:50:02','2026-01-22 17:27:56',0);
/*!40000 ALTER TABLE `t_material_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_purchase`
--

DROP TABLE IF EXISTS `t_material_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_purchase` (
  `id` varchar(36) NOT NULL COMMENT 'é‡‡è´­ID',
  `purchase_no` varchar(50) NOT NULL COMMENT 'é‡‡è´­å•å·',
  `material_code` varchar(50) NOT NULL COMMENT 'ç‰©æ–™ç¼–ç ',
  `material_name` varchar(100) NOT NULL COMMENT 'ç‰©æ–™åç§°',
  `material_type` varchar(20) DEFAULT 'fabric' COMMENT 'ç‰©æ–™ç±»åž‹ï¼šfabric-é¢æ–™ï¼Œaccessory-è¾…æ–™',
  `specifications` varchar(100) DEFAULT NULL COMMENT 'è§„æ ¼',
  `unit` varchar(20) NOT NULL COMMENT 'å•ä½',
  `purchase_quantity` int NOT NULL DEFAULT '0' COMMENT 'é‡‡è´­æ•°é‡',
  `arrived_quantity` int NOT NULL DEFAULT '0' COMMENT 'åˆ°è´§æ•°é‡',
  `supplier_id` varchar(36) DEFAULT NULL COMMENT 'ä¾›åº”å•†ID',
  `supplier_name` varchar(100) DEFAULT NULL COMMENT 'ä¾›åº”å•†åç§°',
  `unit_price` decimal(10,2) DEFAULT '0.00' COMMENT 'å•ä»·',
  `total_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»é‡‘é¢',
  `receiver_id` varchar(36) DEFAULT NULL COMMENT 'æ”¶è´§äººID',
  `receiver_name` varchar(100) DEFAULT NULL COMMENT 'æ”¶è´§äººåç§°',
  `received_time` datetime DEFAULT NULL COMMENT 'æ”¶è´§æ—¶é—´',
  `remark` varchar(500) DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'ç”Ÿäº§è®¢å•ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT 'ç”Ÿäº§è®¢å•å·',
  `style_id` varchar(36) DEFAULT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) DEFAULT NULL COMMENT 'æ¬¾å',
  `style_cover` varchar(500) DEFAULT NULL COMMENT 'æ¬¾å¼å›¾ç‰‡',
  `return_confirmed` int DEFAULT '0' COMMENT 'å›žæ–™æ˜¯å¦ç¡®è®¤(0-å¦,1-æ˜¯)',
  `return_quantity` int DEFAULT '0' COMMENT 'å›žæ–™æ•°é‡',
  `return_confirmer_id` varchar(36) DEFAULT NULL COMMENT 'å›žæ–™ç¡®è®¤äººID',
  `return_confirmer_name` varchar(100) DEFAULT NULL COMMENT 'å›žæ–™ç¡®è®¤äººåç§°',
  `return_confirm_time` datetime DEFAULT NULL COMMENT 'å›žæ–™ç¡®è®¤æ—¶é—´',
  `status` varchar(20) DEFAULT 'pending' COMMENT 'çŠ¶æ€',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `delete_flag` int NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è¯†ï¼š0-æœªåˆ é™¤ï¼Œ1-å·²åˆ é™¤',
  `expected_arrival_date` datetime DEFAULT NULL COMMENT 'é¢„è®¡åˆ°è´§æ—¥æœŸ',
  `actual_arrival_date` datetime DEFAULT NULL COMMENT 'å®žé™…åˆ°è´§æ—¥æœŸ',
  `material_id` varchar(36) DEFAULT NULL COMMENT '物料ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_no` (`purchase_no`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç‰©æ–™é‡‡è´­è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_purchase`
--

LOCK TABLES `t_material_purchase` WRITE;
/*!40000 ALTER TABLE `t_material_purchase` DISABLE KEYS */;
INSERT INTO `t_material_purchase` VALUES ('3e423f638db98492201a28b61fc728a6','PUR20260122144853595726','BTN-376191-06','纽扣','accessoryB','1.5','颗',306,306,'','最美布行',0.20,61.20,'1','系统管理员','2026-01-22 18:43:09',NULL,'0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png',0,0,NULL,NULL,NULL,'completed','2026-01-22 14:48:54','2026-01-22 19:25:03',0,NULL,NULL,'194d8fd0-8801-34cc-a782-e84d3e5c072e'),('45f532d120804f5f637cfe6f3aaae5bd','PUR20260122144853606959','PKG-376191-09','包装袋','accessoryE','0','个',51,51,'','最美布行',0.20,10.20,'1','系统管理员','2026-01-22 18:43:09',NULL,'0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png',0,0,NULL,NULL,NULL,'completed','2026-01-22 14:48:54','2026-01-22 19:25:03',0,NULL,NULL,'6b3048e5-f988-36c0-a643-4e6ed8a771e0'),('47de53773e1949197db24fb6526e7a35','PUR20260122144853610290','INT-376191-04','衬布/粘合衬','liningC','112','米',19,19,'','最美布行',7.00,133.00,'1','系统管理员','2026-01-22 18:43:09',NULL,'0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png',0,0,NULL,NULL,NULL,'completed','2026-01-22 14:48:54','2026-01-22 19:25:03',0,NULL,NULL,'b18779e6-38ba-3a21-84ea-4e5f532d25cd'),('a914389cf997dff1b21e27b66ce675fe','PUR20260122144853586118','FAB-376191-01','主面料','fabricA','150','米',65,65,'','最美布行',15.00,975.00,'1','系统管理员','2026-01-22 18:43:09',NULL,'0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png',0,0,NULL,NULL,NULL,'completed','2026-01-22 14:48:54','2026-01-22 19:25:03',0,NULL,NULL,'fffbe325-9798-3000-aabb-0680a5d156a5'),('c3531fc59929e86ae6c5eaf412cc9aad','PUR20260122144853597294','LBL-376191-08','主唛/洗唛/尺码标','accessoryD','0','套',51,51,'','最美布行',0.50,25.50,'1','系统管理员','2026-01-22 18:43:09',NULL,'0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png',0,0,NULL,NULL,NULL,'completed','2026-01-22 14:48:54','2026-01-22 19:25:03',0,NULL,NULL,'30e54f1e-a469-34df-bd0e-f6557b481807');
/*!40000 ALTER TABLE `t_material_purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_reconciliation`
--

DROP TABLE IF EXISTS `t_material_reconciliation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_reconciliation` (
  `id` varchar(36) NOT NULL COMMENT 'å¯¹è´¦ID',
  `reconciliation_no` varchar(50) NOT NULL COMMENT 'å¯¹è´¦å•å·',
  `supplier_id` varchar(36) NOT NULL COMMENT 'ä¾›åº”å•†ID',
  `supplier_name` varchar(100) NOT NULL COMMENT 'ä¾›åº”å•†åç§°',
  `material_id` varchar(36) NOT NULL COMMENT 'ç‰©æ–™ID',
  `material_code` varchar(50) NOT NULL COMMENT 'ç‰©æ–™ç¼–ç ',
  `material_name` varchar(100) NOT NULL COMMENT 'ç‰©æ–™åç§°',
  `purchase_id` varchar(36) DEFAULT NULL COMMENT 'é‡‡è´­å•ID',
  `purchase_no` varchar(50) DEFAULT NULL COMMENT 'é‡‡è´­å•å·',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'è®¢å•ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT 'è®¢å•å·',
  `style_id` varchar(36) DEFAULT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) DEFAULT NULL COMMENT 'æ¬¾å',
  `quantity` int DEFAULT '0' COMMENT 'æ•°é‡',
  `unit_price` decimal(10,2) DEFAULT '0.00' COMMENT 'å•ä»·',
  `total_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»é‡‘é¢',
  `deduction_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æ‰£æ¬¾é¡¹',
  `final_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æœ€ç»ˆé‡‘é¢',
  `paid_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'å·²ä»˜é‡‘é¢',
  `reconciliation_date` varchar(20) DEFAULT NULL COMMENT 'å¯¹è´¦æ—¥æœŸ',
  `period_start_date` datetime DEFAULT NULL COMMENT 'å¯¹è´¦å‘¨æœŸå¼€å§‹æ—¥æœŸ',
  `period_end_date` datetime DEFAULT NULL COMMENT 'å¯¹è´¦å‘¨æœŸç»“æŸæ—¥æœŸ',
  `status` varchar(20) DEFAULT 'pending' COMMENT 'çŠ¶æ€ï¼špending-å¾…å®¡æ ¸ï¼Œverified-å·²éªŒè¯ï¼Œapproved-å·²æ‰¹å‡†ï¼Œpaid-å·²ä»˜æ¬¾ï¼Œrejected-å·²æ‹’ç»',
  `remark` varchar(255) DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `delete_flag` int DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è¯†ï¼š0-æœªåˆ é™¤ï¼Œ1-å·²åˆ é™¤',
  `reconciliation_operator_id` varchar(36) DEFAULT NULL COMMENT 'å¯¹è´¦äººID',
  `reconciliation_operator_name` varchar(50) DEFAULT NULL COMMENT 'å¯¹è´¦äººå§“å',
  `audit_operator_id` varchar(36) DEFAULT NULL COMMENT 'å®¡æ ¸äººID',
  `audit_operator_name` varchar(50) DEFAULT NULL COMMENT 'å®¡æ ¸äººå§“å',
  `verified_at` datetime DEFAULT NULL COMMENT 'éªŒè¯æ—¶é—´',
  `approved_at` datetime DEFAULT NULL COMMENT 'æ‰¹å‡†æ—¶é—´',
  `paid_at` datetime DEFAULT NULL COMMENT 'ä»˜æ¬¾æ—¶é—´',
  `re_review_at` datetime DEFAULT NULL COMMENT 'å¤å®¡æ—¶é—´',
  `re_review_reason` varchar(255) DEFAULT NULL COMMENT 'å¤å®¡åŽŸå› ',
  `create_by` varchar(36) DEFAULT NULL COMMENT 'åˆ›å»ºäºº',
  `update_by` varchar(36) DEFAULT NULL COMMENT 'æ›´æ–°äºº',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reconciliation_no` (`reconciliation_no`),
  KEY `idx_mr_order_no` (`order_no`),
  KEY `idx_mr_style_no` (`style_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç‰©æ–™é‡‡è´­å¯¹è´¦å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_reconciliation`
--

LOCK TABLES `t_material_reconciliation` WRITE;
/*!40000 ALTER TABLE `t_material_reconciliation` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_reconciliation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_param_config`
--

DROP TABLE IF EXISTS `t_param_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_param_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'é…ç½®ID',
  `param_key` varchar(50) NOT NULL COMMENT 'å‚æ•°é”®',
  `param_value` varchar(200) NOT NULL COMMENT 'å‚æ•°å€¼',
  `param_desc` varchar(200) DEFAULT NULL COMMENT 'å‚æ•°æè¿°',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param_key` (`param_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å‚æ•°é…ç½®è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_param_config`
--

LOCK TABLES `t_param_config` WRITE;
/*!40000 ALTER TABLE `t_param_config` DISABLE KEYS */;
INSERT INTO `t_param_config` VALUES (1,'system.name','æœè£…ä¾›åº”é“¾ç®¡ç†ç³»ç»Ÿ','ç³»ç»Ÿåç§°','2026-01-22 02:41:47','2026-01-22 02:41:47'),(2,'system.version','1.0.0','ç³»ç»Ÿç‰ˆæœ¬','2026-01-22 02:41:47','2026-01-22 02:41:47'),(3,'upload.path','${user.home}/fashion-upload/','æ–‡ä»¶ä¸Šä¼ è·¯å¾„','2026-01-22 02:41:47','2026-01-22 02:41:47');
/*!40000 ALTER TABLE `t_param_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_payroll_settlement`
--

DROP TABLE IF EXISTS `t_payroll_settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_payroll_settlement` (
  `id` varchar(36) NOT NULL,
  `settlement_no` varchar(50) NOT NULL COMMENT 'ç»“ç®—å•å·',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'è®¢å•ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT 'è®¢å•å·',
  `style_id` varchar(36) DEFAULT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) DEFAULT NULL COMMENT 'æ¬¾å',
  `start_time` datetime DEFAULT NULL COMMENT 'å¼€å§‹æ—¶é—´',
  `end_time` datetime DEFAULT NULL COMMENT 'ç»“æŸæ—¶é—´',
  `total_quantity` int DEFAULT '0' COMMENT 'æ€»æ•°é‡',
  `total_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»é‡‘é¢',
  `status` varchar(20) DEFAULT NULL COMMENT 'çŠ¶æ€',
  `remark` varchar(255) DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `create_by` varchar(36) DEFAULT NULL COMMENT 'åˆ›å»ºäºº',
  `update_by` varchar(36) DEFAULT NULL COMMENT 'æ›´æ–°äºº',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_payroll_settlement_no` (`settlement_no`),
  KEY `idx_payroll_order_no` (`order_no`),
  KEY `idx_payroll_style_no` (`style_no`),
  KEY `idx_payroll_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å·¥èµ„ç»“ç®—å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_payroll_settlement`
--

LOCK TABLES `t_payroll_settlement` WRITE;
/*!40000 ALTER TABLE `t_payroll_settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_payroll_settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_payroll_settlement_item`
--

DROP TABLE IF EXISTS `t_payroll_settlement_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_payroll_settlement_item` (
  `id` varchar(36) NOT NULL,
  `settlement_id` varchar(36) NOT NULL COMMENT 'ç»“ç®—å•ID',
  `operator_id` varchar(36) DEFAULT NULL COMMENT 'äººå‘˜ID',
  `operator_name` varchar(50) DEFAULT NULL COMMENT 'äººå‘˜åç§°',
  `process_name` varchar(100) DEFAULT NULL COMMENT 'å·¥åºåç§°',
  `quantity` int DEFAULT '0' COMMENT 'æ•°é‡',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'å•ä»·',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT 'æ€»é‡‘é¢',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'è®¢å•ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT 'è®¢å•å·',
  `style_no` varchar(50) DEFAULT NULL COMMENT 'æ¬¾å·',
  `scan_type` varchar(20) DEFAULT NULL COMMENT 'æ‰«ç ç±»åž‹',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_payroll_item_settlement_id` (`settlement_id`),
  KEY `idx_payroll_item_operator_id` (`operator_id`),
  KEY `idx_payroll_item_order_no` (`order_no`),
  KEY `idx_payroll_item_style_no` (`style_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å·¥èµ„ç»“ç®—æ˜Žç»†è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_payroll_settlement_item`
--

LOCK TABLES `t_payroll_settlement_item` WRITE;
/*!40000 ALTER TABLE `t_payroll_settlement_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_payroll_settlement_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_permission`
--

DROP TABLE IF EXISTS `t_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_permission` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æƒé™ID',
  `permission_name` varchar(50) NOT NULL COMMENT 'æƒé™åç§°',
  `permission_code` varchar(50) NOT NULL COMMENT 'æƒé™ç¼–ç ',
  `permission_type` varchar(20) NOT NULL COMMENT 'æƒé™ç±»åž‹ï¼šMENU-èœå•ï¼ŒBUTTON-æŒ‰é’®',
  `parent_id` bigint DEFAULT '0' COMMENT 'çˆ¶æƒé™ID',
  `parent_name` varchar(50) DEFAULT NULL COMMENT 'çˆ¶æƒé™åç§°',
  `path` varchar(100) DEFAULT NULL COMMENT 'è®¿é—®è·¯å¾„',
  `component` varchar(100) DEFAULT NULL COMMENT 'ç»„ä»¶è·¯å¾„',
  `icon` varchar(50) DEFAULT NULL COMMENT 'å›¾æ ‡',
  `sort` int DEFAULT '0' COMMENT 'æŽ’åº',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_code` (`permission_code`)
) ENGINE=InnoDB AUTO_INCREMENT=712 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æƒé™è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_permission`
--

LOCK TABLES `t_permission` WRITE;
/*!40000 ALTER TABLE `t_permission` DISABLE KEYS */;
INSERT INTO `t_permission` VALUES (1,'仪表盘','MENU_DASHBOARD','menu',0,NULL,'/dashboard',NULL,NULL,0,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(2,'基础资料','MENU_BASIC','menu',0,NULL,NULL,NULL,NULL,10,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(3,'生产管理','MENU_PRODUCTION','menu',0,NULL,NULL,NULL,NULL,20,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(4,'财务管理','MENU_FINANCE','menu',0,NULL,NULL,NULL,NULL,30,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(5,'系统设置','MENU_SYSTEM','menu',0,NULL,NULL,NULL,NULL,40,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(6,'款号资料','MENU_STYLE_INFO','menu',2,'基础资料','/style-info',NULL,NULL,11,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(7,'下单管理','MENU_ORDER_MANAGEMENT','menu',2,'基础资料','/order-management',NULL,NULL,12,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(8,'资料中心','MENU_DATA_CENTER','menu',2,'基础资料','/data-center',NULL,NULL,13,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(9,'模板中心','MENU_TEMPLATE_CENTER','menu',2,'基础资料','/basic/template-center',NULL,NULL,14,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(10,'我的订单','MENU_PRODUCTION_LIST','menu',3,'生产管理','/production',NULL,NULL,21,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(11,'物料采购','MENU_MATERIAL_PURCHASE','menu',3,'生产管理','/production/material',NULL,NULL,22,'active','2026-01-22 02:42:15','2026-01-22 02:42:15'),(12,'裁剪管理','MENU_CUTTING','menu',3,'生产管理','/production/cutting',NULL,NULL,23,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(13,'生产进度','MENU_PROGRESS','menu',3,'生产管理','/production/progress-detail',NULL,NULL,24,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(14,'质检入库','MENU_WAREHOUSING','menu',3,'生产管理','/production/warehousing',NULL,NULL,25,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(15,'物料对账','MENU_MATERIAL_RECON','menu',4,'财务管理','/finance/material-reconciliation',NULL,NULL,32,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(16,'成品结算','MENU_SHIPMENT_RECON','menu',4,'财务管理','/finance/shipment-reconciliation',NULL,NULL,33,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(17,'审批付款','MENU_PAYMENT_APPROVAL','menu',4,'财务管理','/finance/payment-approval',NULL,NULL,34,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(18,'人员工序统计','MENU_PAYROLL_OPERATOR_SUMMARY','menu',4,'财务管理','/finance/payroll-operator-summary',NULL,NULL,35,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(19,'人员管理','MENU_USER','menu',5,'系统设置','/system/user',NULL,NULL,41,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(20,'角色管理','MENU_ROLE','menu',5,'系统设置','/system/role',NULL,NULL,42,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(21,'供应商管理','MENU_FACTORY','menu',5,'系统设置','/system/factory',NULL,NULL,43,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(22,'权限管理','MENU_PERMISSION','menu',5,'系统设置','/system/permission',NULL,NULL,44,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(23,'登录日志','MENU_LOGIN_LOG','menu',5,'系统设置','/system/login-log',NULL,NULL,45,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(24,'新增款号','STYLE_CREATE','button',0,NULL,NULL,NULL,NULL,100,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(25,'编辑款号','STYLE_EDIT','button',0,NULL,NULL,NULL,NULL,101,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(26,'删除款号','STYLE_DELETE','button',0,NULL,NULL,NULL,NULL,102,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(27,'导入款号','STYLE_IMPORT','button',0,NULL,NULL,NULL,NULL,103,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(28,'导出款号','STYLE_EXPORT','button',0,NULL,NULL,NULL,NULL,104,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(29,'新增订单','ORDER_CREATE','button',0,NULL,NULL,NULL,NULL,110,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(30,'编辑订单','ORDER_EDIT','button',0,NULL,NULL,NULL,NULL,111,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(31,'删除订单','ORDER_DELETE','button',0,NULL,NULL,NULL,NULL,112,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(32,'取消订单','ORDER_CANCEL','button',0,NULL,NULL,NULL,NULL,113,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(33,'完成订单','ORDER_COMPLETE','button',0,NULL,NULL,NULL,NULL,114,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(34,'导入订单','ORDER_IMPORT','button',0,NULL,NULL,NULL,NULL,115,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(35,'导出订单','ORDER_EXPORT','button',0,NULL,NULL,NULL,NULL,116,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(36,'订单转移','ORDER_TRANSFER','button',0,NULL,NULL,NULL,NULL,117,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(37,'新增采购单','PURCHASE_CREATE','button',0,NULL,NULL,NULL,NULL,120,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(38,'编辑采购单','PURCHASE_EDIT','button',0,NULL,NULL,NULL,NULL,121,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(39,'删除采购单','PURCHASE_DELETE','button',0,NULL,NULL,NULL,NULL,122,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(40,'领取采购任务','PURCHASE_RECEIVE','button',0,NULL,NULL,NULL,NULL,123,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(41,'回料确认','PURCHASE_RETURN_CONFIRM','button',0,NULL,NULL,NULL,NULL,124,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(42,'生成采购单','PURCHASE_GENERATE','button',0,NULL,NULL,NULL,NULL,125,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(43,'新增裁剪','CUTTING_CREATE','button',0,NULL,NULL,NULL,NULL,130,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(44,'编辑裁剪','CUTTING_EDIT','button',0,NULL,NULL,NULL,NULL,131,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(45,'删除裁剪','CUTTING_DELETE','button',0,NULL,NULL,NULL,NULL,132,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(46,'裁剪扫码','CUTTING_SCAN','button',0,NULL,NULL,NULL,NULL,133,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(47,'进度扫码','PROGRESS_SCAN','button',0,NULL,NULL,NULL,NULL,140,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(48,'编辑进度','PROGRESS_EDIT','button',0,NULL,NULL,NULL,NULL,141,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(49,'删除进度','PROGRESS_DELETE','button',0,NULL,NULL,NULL,NULL,142,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(50,'新增入库','WAREHOUSING_CREATE','button',0,NULL,NULL,NULL,NULL,150,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(51,'编辑入库','WAREHOUSING_EDIT','button',0,NULL,NULL,NULL,NULL,151,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(52,'删除入库','WAREHOUSING_DELETE','button',0,NULL,NULL,NULL,NULL,152,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(53,'入库回退','WAREHOUSING_ROLLBACK','button',0,NULL,NULL,NULL,NULL,153,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(54,'新增对账单','MATERIAL_RECON_CREATE','button',0,NULL,NULL,NULL,NULL,160,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(55,'编辑对账单','MATERIAL_RECON_EDIT','button',0,NULL,NULL,NULL,NULL,161,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(56,'删除对账单','MATERIAL_RECON_DELETE','button',0,NULL,NULL,NULL,NULL,162,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(57,'审核对账单','MATERIAL_RECON_AUDIT','button',0,NULL,NULL,NULL,NULL,163,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(58,'结算对账单','MATERIAL_RECON_SETTLEMENT','button',0,NULL,NULL,NULL,NULL,164,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(59,'新增结算单','SHIPMENT_RECON_CREATE','button',0,NULL,NULL,NULL,NULL,170,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(60,'编辑结算单','SHIPMENT_RECON_EDIT','button',0,NULL,NULL,NULL,NULL,171,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(61,'删除结算单','SHIPMENT_RECON_DELETE','button',0,NULL,NULL,NULL,NULL,172,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(62,'审核结算单','SHIPMENT_RECON_AUDIT','button',0,NULL,NULL,NULL,NULL,173,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(63,'审批付款','PAYMENT_APPROVE','button',0,NULL,NULL,NULL,NULL,180,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(64,'拒绝付款','PAYMENT_REJECT','button',0,NULL,NULL,NULL,NULL,181,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(65,'取消付款','PAYMENT_CANCEL','button',0,NULL,NULL,NULL,NULL,182,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(66,'新增用户','USER_CREATE','button',0,NULL,NULL,NULL,NULL,190,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(67,'编辑用户','USER_EDIT','button',0,NULL,NULL,NULL,NULL,191,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(68,'删除用户','USER_DELETE','button',0,NULL,NULL,NULL,NULL,192,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(69,'重置密码','USER_RESET_PASSWORD','button',0,NULL,NULL,NULL,NULL,193,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(70,'新增角色','ROLE_CREATE','button',0,NULL,NULL,NULL,NULL,200,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(71,'编辑角色','ROLE_EDIT','button',0,NULL,NULL,NULL,NULL,201,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(72,'删除角色','ROLE_DELETE','button',0,NULL,NULL,NULL,NULL,202,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(73,'新增供应商','FACTORY_CREATE','button',0,NULL,NULL,NULL,NULL,210,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(74,'编辑供应商','FACTORY_EDIT','button',0,NULL,NULL,NULL,NULL,211,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(75,'删除供应商','FACTORY_DELETE','button',0,NULL,NULL,NULL,NULL,212,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(76,'数据导入','DATA_IMPORT','button',0,NULL,NULL,NULL,NULL,220,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(77,'数据导出','DATA_EXPORT','button',0,NULL,NULL,NULL,NULL,221,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(78,'上传模板','TEMPLATE_UPLOAD','button',0,NULL,NULL,NULL,NULL,230,'active','2026-01-22 02:42:16','2026-01-22 02:42:16'),(79,'删除模板','TEMPLATE_DELETE','button',0,NULL,NULL,NULL,NULL,231,'active','2026-01-22 02:42:16','2026-01-22 02:42:16');
/*!40000 ALTER TABLE `t_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_product_outstock`
--

DROP TABLE IF EXISTS `t_product_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_product_outstock` (
  `id` varchar(36) NOT NULL,
  `outstock_no` varchar(50) NOT NULL COMMENT '出库单号',
  `order_id` varchar(36) NOT NULL COMMENT '订单ID',
  `order_no` varchar(50) NOT NULL COMMENT '订单号',
  `style_id` varchar(36) DEFAULT NULL COMMENT '款号ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT '款号',
  `style_name` varchar(100) DEFAULT NULL COMMENT '款名',
  `outstock_quantity` int NOT NULL DEFAULT '0' COMMENT '出库数量',
  `outstock_type` varchar(20) DEFAULT 'shipment' COMMENT '出库类型',
  `warehouse` varchar(50) DEFAULT NULL COMMENT '仓库',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `delete_flag` int NOT NULL DEFAULT '0' COMMENT '删除标识：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `outstock_no` (`outstock_no`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='成品出库表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_product_outstock`
--

LOCK TABLES `t_product_outstock` WRITE;
/*!40000 ALTER TABLE `t_product_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_product_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_product_warehousing`
--

DROP TABLE IF EXISTS `t_product_warehousing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_product_warehousing` (
  `id` varchar(36) NOT NULL,
  `warehousing_no` varchar(50) NOT NULL COMMENT 'å…¥åº“å•å·',
  `order_id` varchar(36) NOT NULL COMMENT 'ç”Ÿäº§è®¢å•ID',
  `order_no` varchar(50) NOT NULL COMMENT 'ç”Ÿäº§è®¢å•å·',
  `style_id` varchar(36) NOT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) NOT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) NOT NULL COMMENT 'æ¬¾å',
  `warehousing_quantity` int NOT NULL DEFAULT '0' COMMENT 'å…¥åº“æ•°é‡',
  `qualified_quantity` int NOT NULL DEFAULT '0' COMMENT 'åˆæ ¼æ•°é‡',
  `unqualified_quantity` int NOT NULL DEFAULT '0' COMMENT 'ä¸åˆæ ¼æ•°é‡',
  `warehousing_type` varchar(20) DEFAULT 'manual' COMMENT 'å…¥åº“ç±»åž‹',
  `warehouse` varchar(50) DEFAULT NULL COMMENT 'ä»“åº“',
  `quality_status` varchar(20) DEFAULT 'qualified' COMMENT 'è´¨æ£€çŠ¶æ€',
  `cutting_bundle_id` varchar(36) DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·ID',
  `cutting_bundle_no` int DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·åºå·',
  `cutting_bundle_qr_code` varchar(200) DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·äºŒç»´ç å†…å®¹',
  `unqualified_image_urls` varchar(2000) DEFAULT NULL COMMENT 'ä¸åˆæ ¼å›¾ç‰‡URLåˆ—è¡¨(JSON)',
  `defect_category` varchar(64) DEFAULT NULL COMMENT 'æ¬¡å“ç±»åˆ«',
  `defect_remark` varchar(500) DEFAULT NULL COMMENT 'æ¬¡å“å¤‡æ³¨',
  `repair_remark` varchar(500) DEFAULT NULL COMMENT 'è¿”ä¿®å¤‡æ³¨',
  `receiver_id` varchar(36) DEFAULT NULL COMMENT 'é¢†å–äººID',
  `receiver_name` varchar(50) DEFAULT NULL COMMENT 'é¢†å–äººåç§°',
  `received_time` datetime DEFAULT NULL COMMENT 'é¢†å–æ—¶é—´',
  `inspection_status` varchar(20) DEFAULT NULL COMMENT 'éªŒæ”¶çŠ¶æ€',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `delete_flag` int NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ ‡è¯†ï¼š0-æœªåˆ é™¤ï¼Œ1-å·²åˆ é™¤',
  `quality_operator_id` varchar(64) DEFAULT NULL COMMENT 'è´¨æ£€æ“ä½œäººID',
  `quality_operator_name` varchar(128) DEFAULT NULL COMMENT 'è´¨æ£€æ“ä½œäººå§“å',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_cutting_bundle_id` (`cutting_bundle_id`),
  KEY `idx_warehousing_no` (`warehousing_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='è´¨æ£€å…¥åº“è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_product_warehousing`
--

LOCK TABLES `t_product_warehousing` WRITE;
/*!40000 ALTER TABLE `t_product_warehousing` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_product_warehousing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_order`
--

DROP TABLE IF EXISTS `t_production_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_order` (
  `id` varchar(36) NOT NULL COMMENT 'è®¢å•ID',
  `order_no` varchar(50) NOT NULL COMMENT 'è®¢å•å·',
  `style_id` varchar(36) NOT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) NOT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) NOT NULL COMMENT 'æ¬¾å',
  `factory_id` varchar(36) NOT NULL COMMENT 'åŠ å·¥åŽ‚ID',
  `factory_name` varchar(100) NOT NULL COMMENT 'åŠ å·¥åŽ‚åç§°',
  `order_quantity` int DEFAULT '0' COMMENT 'è®¢å•æ•°é‡',
  `completed_quantity` int DEFAULT '0' COMMENT 'å®Œæˆæ•°é‡',
  `material_arrival_rate` int DEFAULT '0' COMMENT 'ç‰©æ–™åˆ°ä½çŽ‡(%)',
  `production_progress` int DEFAULT '0' COMMENT 'ç”Ÿäº§è¿›åº¦(%)',
  `status` varchar(20) DEFAULT 'pending' COMMENT 'çŠ¶æ€ï¼špending-å¾…ç”Ÿäº§ï¼Œproduction-ç”Ÿäº§ä¸­ï¼Œcompleted-å·²å®Œæˆï¼Œdelayed-å·²é€¾æœŸ',
  `planned_start_date` datetime DEFAULT NULL COMMENT 'è®¡åˆ’å¼€å§‹æ—¥æœŸ',
  `planned_end_date` datetime DEFAULT NULL COMMENT 'è®¡åˆ’å®Œæˆæ—¥æœŸ',
  `actual_start_date` datetime DEFAULT NULL COMMENT 'å®žé™…å¼€å§‹æ—¥æœŸ',
  `actual_end_date` datetime DEFAULT NULL COMMENT 'å®žé™…å®Œæˆæ—¥æœŸ',
  `delete_flag` int DEFAULT '0' COMMENT 'åˆ é™¤æ ‡å¿—(0:æ­£å¸¸,1:åˆ é™¤)',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `qr_code` varchar(100) DEFAULT NULL COMMENT '订单二维码内容',
  `color` varchar(50) DEFAULT NULL COMMENT '颜色',
  `size` varchar(50) DEFAULT NULL COMMENT '码数',
  `order_details` longtext COMMENT '订单明细JSON',
  `progress_workflow_json` longtext COMMENT '进度节点定义JSON',
  `progress_workflow_locked` int NOT NULL DEFAULT '0' COMMENT '进度节点是否锁定：0-否，1-是',
  `progress_workflow_locked_at` datetime DEFAULT NULL COMMENT '进度节点锁定时间',
  `progress_workflow_locked_by` varchar(36) DEFAULT NULL COMMENT '进度节点锁定人ID',
  `progress_workflow_locked_by_name` varchar(50) DEFAULT NULL COMMENT '进度节点锁定人',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç”Ÿäº§è®¢å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_order`
--

LOCK TABLES `t_production_order` WRITE;
/*!40000 ALTER TABLE `t_production_order` DISABLE KEYS */;
INSERT INTO `t_production_order` VALUES ('0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','衬衫','872055c6327a18338bd1c8788e4e3158','最美服装工厂',50,0,100,20,'production','2026-01-22 14:46:31','2026-01-29 14:46:31',NULL,NULL,0,'2026-01-22 14:48:53','2026-01-22 19:47:14','PO20260122001','格子灰色','S,M,L,XL,XXL','[{\"color\":\"格子灰色\",\"size\":\"S\",\"quantity\":10,\"materialPriceSource\":\"物料采购系统\",\"materialPriceAcquiredAt\":\"2026-01-22T06:48:53.340Z\",\"materialPriceVersion\":\"purchase.v1\"},{\"color\":\"格子灰色\",\"size\":\"M\",\"quantity\":10,\"materialPriceSource\":\"物料采购系统\",\"materialPriceAcquiredAt\":\"2026-01-22T06:48:53.340Z\",\"materialPriceVersion\":\"purchase.v1\"},{\"color\":\"格子灰色\",\"size\":\"L\",\"quantity\":10,\"materialPriceSource\":\"物料采购系统\",\"materialPriceAcquiredAt\":\"2026-01-22T06:48:53.340Z\",\"materialPriceVersion\":\"purchase.v1\"},{\"color\":\"格子灰色\",\"size\":\"XL\",\"quantity\":10,\"materialPriceSource\":\"物料采购系统\",\"materialPriceAcquiredAt\":\"2026-01-22T06:48:53.340Z\",\"materialPriceVersion\":\"purchase.v1\"},{\"color\":\"格子灰色\",\"size\":\"XXL\",\"quantity\":10,\"materialPriceSource\":\"物料采购系统\",\"materialPriceAcquiredAt\":\"2026-01-22T06:48:53.340Z\",\"materialPriceVersion\":\"purchase.v1\"}]','{\"nodes\":[{\"name\":\"采购\",\"unitPrice\":0,\"id\":\"purchase\"},{\"name\":\"裁剪\",\"unitPrice\":0,\"id\":\"cutting\"},{\"name\":\"车缝\",\"unitPrice\":15,\"id\":\"sewing\"},{\"name\":\"大烫\",\"unitPrice\":0,\"id\":\"pressing\"},{\"name\":\"质检\",\"unitPrice\":0,\"id\":\"quality\"},{\"name\":\"包装\",\"unitPrice\":0,\"id\":\"packaging\"},{\"name\":\"入库\",\"unitPrice\":0,\"id\":\"warehousing\"}]}',1,'2026-01-22 19:47:14','1','系统管理员');
/*!40000 ALTER TABLE `t_production_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è§’è‰²ID',
  `role_name` varchar(50) NOT NULL COMMENT 'è§’è‰²åç§°',
  `role_code` varchar(50) NOT NULL COMMENT 'è§’è‰²ç¼–ç ',
  `description` varchar(200) DEFAULT NULL COMMENT 'è§’è‰²æè¿°',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `data_scope` varchar(20) DEFAULT 'ALL' COMMENT '数据权限范围',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='è§’è‰²è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` VALUES (1,'管理员','admin','系统管理员，拥有所有权限','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(2,'普通用户','user','普通用户，基本权限','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(3,'主管','supervisor','主管角色，拥有全部数据查看权限','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(4,'采购员','purchaser','采购员角色，负责物料采购','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(5,'裁剪员','cutter','裁剪员角色，负责裁剪任务','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(6,'车缝员','sewing','车缝员角色，负责车缝工序','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(7,'åŒ…è£…å‘˜','packager','包装员角色，负责成品包装','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(8,'质检员','quality','质检员角色，负责质量检查','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL'),(9,'仓管员','warehouse','仓管员角色，负责仓库管理','ENABLED','2026-01-22 02:41:47','2026-01-22 03:21:36','ALL');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role_permission`
--

DROP TABLE IF EXISTS `t_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_role_permission` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `role_id` bigint NOT NULL COMMENT 'è§’è‰²ID',
  `permission_id` bigint NOT NULL COMMENT 'æƒé™ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_permission` (`role_id`,`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='è§’è‰²æƒé™å…³è”è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role_permission`
--

LOCK TABLES `t_role_permission` WRITE;
/*!40000 ALTER TABLE `t_role_permission` DISABLE KEYS */;
INSERT INTO `t_role_permission` VALUES (17,1,1),(15,1,2),(28,1,3),(20,1,4),(34,1,5),(33,1,6),(24,1,7),(18,1,8),(35,1,9),(29,1,10),(22,1,11),(16,1,12),(30,1,13),(37,1,14),(23,1,15),(32,1,16),(25,1,17),(26,1,18),(36,1,19),(31,1,20),(19,1,21),(27,1,22),(21,1,23),(65,1,24),(67,1,25),(66,1,26),(69,1,27),(68,1,28),(40,1,29),(42,1,30),(41,1,31),(38,1,32),(39,1,33),(44,1,34),(43,1,35),(45,1,36),(52,1,37),(54,1,38),(53,1,39),(56,1,40),(57,1,41),(55,1,42),(1,1,43),(3,1,44),(2,1,45),(4,1,46),(51,1,47),(50,1,48),(49,1,49),(76,1,50),(78,1,51),(77,1,52),(79,1,53),(11,1,54),(13,1,55),(12,1,56),(10,1,57),(14,1,58),(62,1,59),(64,1,60),(63,1,61),(61,1,62),(46,1,63),(48,1,64),(47,1,65),(72,1,66),(74,1,67),(73,1,68),(75,1,69),(58,1,70),(60,1,71),(59,1,72),(7,1,73),(9,1,74),(8,1,75),(6,1,76),(5,1,77),(71,1,78),(70,1,79);
/*!40000 ALTER TABLE `t_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_scan_record`
--

DROP TABLE IF EXISTS `t_scan_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_scan_record` (
  `id` varchar(36) NOT NULL,
  `scan_code` varchar(200) DEFAULT NULL COMMENT '扫码内容',
  `request_id` varchar(64) DEFAULT NULL COMMENT 'å¹‚ç­‰è¯·æ±‚ID',
  `order_id` varchar(36) DEFAULT NULL COMMENT 'è®¢å•ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT 'è®¢å•å·',
  `style_id` varchar(36) DEFAULT NULL COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT 'æ¬¾å·',
  `color` varchar(50) DEFAULT NULL COMMENT 'é¢œè‰²',
  `size` varchar(50) DEFAULT NULL COMMENT 'ç æ•°',
  `quantity` int NOT NULL DEFAULT '0' COMMENT 'æ•°é‡',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT 'å•ä»·',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT 'é‡‘é¢',
  `settlement_status` varchar(20) DEFAULT NULL COMMENT 'æ ¸ç®—çŠ¶æ€',
  `payroll_settlement_id` varchar(36) DEFAULT NULL COMMENT 'å·¥èµ„ç»“ç®—å•ID',
  `process_code` varchar(50) DEFAULT NULL COMMENT 'å·¥åºç¼–ç ',
  `progress_stage` varchar(100) DEFAULT NULL COMMENT 'è¿›åº¦çŽ¯èŠ‚',
  `process_name` varchar(100) DEFAULT NULL COMMENT 'å·¥åºåç§°',
  `operator_id` varchar(36) DEFAULT NULL COMMENT 'æ“ä½œå‘˜ID',
  `operator_name` varchar(50) DEFAULT NULL COMMENT 'æ“ä½œå‘˜åç§°',
  `scan_type` varchar(20) DEFAULT 'production' COMMENT 'æ‰«ç ç±»åž‹',
  `scan_result` varchar(20) DEFAULT 'success' COMMENT 'æ‰«ç ç»“æžœ',
  `remark` varchar(255) DEFAULT NULL COMMENT 'å¤‡æ³¨',
  `scan_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'æ‰«ç æ—¶é—´',
  `scan_ip` varchar(20) DEFAULT NULL COMMENT 'æ‰«ç IP',
  `cutting_bundle_id` varchar(36) DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·ID',
  `cutting_bundle_no` int DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·åºå·',
  `cutting_bundle_qr_code` varchar(200) DEFAULT NULL COMMENT 'è£å‰ªæ‰Žå·äºŒç»´ç å†…å®¹',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scan_request_id` (`request_id`),
  UNIQUE KEY `uk_bundle_stage` (`cutting_bundle_id`,`scan_type`,`progress_stage`),
  UNIQUE KEY `uk_bundle_stage_progress` (`cutting_bundle_id`,`scan_type`,`progress_stage`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_request_id` (`request_id`),
  KEY `idx_scan_time` (`scan_time`),
  KEY `idx_payroll_settlement_id` (`payroll_settlement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ‰«ç è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_scan_record`
--

LOCK TABLES `t_scan_record` WRITE;
/*!40000 ALTER TABLE `t_scan_record` DISABLE KEYS */;
INSERT INTO `t_scan_record` VALUES ('085f8a03f3845e9960f9efd139b4218f',NULL,'ORDER_CREATED:0699c85d4495e0f1a74ba6e75c17cc88','0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','格子灰色','S,M,L,XL,XXL',50,NULL,NULL,NULL,NULL,NULL,'下单','下单',NULL,'system','production','success','下单','2026-01-22 14:48:53',NULL,NULL,NULL,NULL,'2026-01-22 14:48:53','2026-01-22 19:25:03'),('f9f853b6e3dfa4bb55dfe80f108a3f97',NULL,'ORDER_PROCUREMENT:0699c85d4495e0f1a74ba6e75c17cc88','0699c85d4495e0f1a74ba6e75c17cc88','PO20260122001','4','ST2026012200111','格子灰色','S,M,L,XL,XXL',50,NULL,NULL,NULL,NULL,NULL,'采购','采购','1','system','production','success','采购','2026-01-22 19:25:03',NULL,NULL,NULL,NULL,'2026-01-22 14:48:53','2026-01-22 19:25:03');
/*!40000 ALTER TABLE `t_scan_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_serial_rule`
--

DROP TABLE IF EXISTS `t_serial_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_serial_rule` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è§„åˆ™ID',
  `rule_code` varchar(50) NOT NULL COMMENT 'è§„åˆ™ç¼–ç ',
  `rule_name` varchar(100) NOT NULL COMMENT 'è§„åˆ™åç§°',
  `rule_pattern` varchar(100) NOT NULL COMMENT 'è§„åˆ™æ¨¡æ¿',
  `current_no` bigint DEFAULT '0' COMMENT 'å½“å‰åºå·',
  `prefix` varchar(20) DEFAULT NULL COMMENT 'å‰ç¼€',
  `suffix` varchar(20) DEFAULT NULL COMMENT 'åŽç¼€',
  `date_format` varchar(20) DEFAULT NULL COMMENT 'æ—¥æœŸæ ¼å¼',
  `digit_length` int DEFAULT '4' COMMENT 'åºå·ä½æ•°',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_code` (`rule_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æµæ°´å·è§„åˆ™è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_serial_rule`
--

LOCK TABLES `t_serial_rule` WRITE;
/*!40000 ALTER TABLE `t_serial_rule` DISABLE KEYS */;
INSERT INTO `t_serial_rule` VALUES (1,'STYLE_NO','æ¬¾å·è§„åˆ™','STYLE{yyyyMM}{no}',0,'STYLE',NULL,'yyyyMM',4,'2026-01-22 02:41:47','2026-01-22 02:41:47'),(2,'ORDER_NO','è®¢å•å·è§„åˆ™','ORDER{yyyyMMdd}{no}',0,'ORDER',NULL,'yyyyMMdd',4,'2026-01-22 02:41:47','2026-01-22 02:41:47'),(3,'PURCHASE_NO','é‡‡è´­å•å·è§„åˆ™','PURCHASE{yyyyMMdd}{no}',0,'PURCHASE',NULL,'yyyyMMdd',4,'2026-01-22 02:41:47','2026-01-22 02:41:47');
/*!40000 ALTER TABLE `t_serial_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_shipment_reconciliation`
--

DROP TABLE IF EXISTS `t_shipment_reconciliation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_shipment_reconciliation` (
  `id` varchar(36) NOT NULL,
  `reconciliation_no` varchar(50) NOT NULL COMMENT 'å¯¹è´¦å•å·',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `reconciliation_date` date NOT NULL COMMENT 'å¯¹è´¦æ—¥æœŸ',
  `total_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»é‡‘é¢',
  `received_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'å·²æ”¶é‡‘é¢',
  `outstanding_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'æœªæ”¶é‡‘é¢',
  `status` varchar(20) DEFAULT 'PENDING' COMMENT 'çŠ¶æ€ï¼šPENDING-å¾…å¯¹è´¦ï¼ŒCONFIRMED-å·²ç¡®è®¤ï¼ŒSETTLED-å·²ç»“ç®—',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `customer_id` varchar(36) DEFAULT NULL COMMENT '客户ID',
  `style_id` varchar(36) DEFAULT NULL COMMENT '款号ID',
  `style_no` varchar(50) DEFAULT NULL COMMENT '款号',
  `style_name` varchar(100) DEFAULT NULL COMMENT '款名',
  `order_id` varchar(36) DEFAULT NULL COMMENT '订单ID',
  `order_no` varchar(50) DEFAULT NULL COMMENT '订单号',
  `quantity` int DEFAULT '0' COMMENT '数量',
  `unit_price` decimal(10,2) DEFAULT '0.00' COMMENT '单价',
  `deduction_amount` decimal(10,2) DEFAULT '0.00' COMMENT '扣款项金额',
  `final_amount` decimal(10,2) DEFAULT '0.00' COMMENT '最终金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(36) DEFAULT NULL COMMENT '创建人',
  `update_by` varchar(36) DEFAULT NULL COMMENT '更新人',
  `paid_at` datetime DEFAULT NULL COMMENT '付款时间',
  `verified_at` datetime DEFAULT NULL COMMENT '验证时间',
  `approved_at` datetime DEFAULT NULL COMMENT '批准时间',
  `re_review_at` datetime DEFAULT NULL COMMENT '重审时间',
  `re_review_reason` varchar(255) DEFAULT NULL COMMENT '重审原因',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reconciliation_no` (`reconciliation_no`),
  KEY `idx_status` (`status`),
  KEY `idx_reconciliation_no` (`reconciliation_no`),
  KEY `idx_customer_name` (`customer_name`),
  KEY `idx_style_no` (`style_no`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æˆå“å‡ºè´§å¯¹è´¦å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_shipment_reconciliation`
--

LOCK TABLES `t_shipment_reconciliation` WRITE;
/*!40000 ALTER TABLE `t_shipment_reconciliation` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_shipment_reconciliation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_attachment`
--

DROP TABLE IF EXISTS `t_style_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_attachment` (
  `id` varchar(36) NOT NULL,
  `style_id` bigint NOT NULL COMMENT 'æ¬¾å·ID',
  `file_name` varchar(100) NOT NULL COMMENT 'æ–‡ä»¶å',
  `file_type` varchar(200) NOT NULL COMMENT '文件类型',
  `file_size` bigint NOT NULL COMMENT 'æ–‡ä»¶å¤§å°(å­—èŠ‚)',
  `file_url` varchar(200) NOT NULL COMMENT 'æ–‡ä»¶URL',
  `version` int DEFAULT '1' COMMENT 'ç‰ˆæœ¬å·',
  `version_remark` varchar(255) DEFAULT NULL COMMENT 'ç‰ˆæœ¬è¯´æ˜Ž',
  `status` varchar(20) DEFAULT 'active' COMMENT 'çŠ¶æ€',
  `parent_id` varchar(36) DEFAULT NULL COMMENT 'çˆ¶ç‰ˆæœ¬ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `uploader` varchar(50) DEFAULT NULL COMMENT 'ä¸Šä¼ äºº',
  `biz_type` varchar(20) DEFAULT 'general' COMMENT 'ä¸šåŠ¡ç±»åž‹',
  PRIMARY KEY (`id`),
  KEY `idx_style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·é™„ä»¶è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_attachment`
--

LOCK TABLES `t_style_attachment` WRITE;
/*!40000 ALTER TABLE `t_style_attachment` DISABLE KEYS */;
INSERT INTO `t_style_attachment` VALUES ('1a84c19c33c58eb78d2ab52f55347492',3,'WQY230800152-妈妈.ets','application/octet-stream',590569,'/api/common/download/914d8b95-ad71-431d-b123-3c22f1b2d053.ets',1,NULL,'active',NULL,'2026-01-22 12:01:32','2026-01-22 04:01:32','ç³»ç»Ÿç®¡ç†å‘˜','pattern_grading'),('360d6db421d4d5812aa670fafd126af5',4,'WQY230800152-妈妈.ets','application/octet-stream',590569,'/api/common/download/8dec459a-ef18-425a-af93-1f5286b005b4.ets',1,NULL,'active',NULL,'2026-01-22 14:19:32','2026-01-22 06:19:31','ç³»ç»Ÿç®¡ç†å‘˜','pattern_grading'),('5c1fc962bdd3afc4facfd924315097d7',3,'WQY230800152-妈妈.ets','application/octet-stream',590569,'/api/common/download/87fd1371-ee5b-4313-a4e4-23bebc4056ff.ets',1,NULL,'active',NULL,'2026-01-22 11:55:28','2026-01-22 04:00:08','系统管理员','pattern'),('791c7f1426b8c1e7807daeae73b977c0',4,'WQY230800152-妈妈.ets','application/octet-stream',590569,'/api/common/download/40dc47e1-0454-4c14-8b6c-dd5faee9d0a3.ets',1,NULL,'active',NULL,'2026-01-22 14:19:21','2026-01-22 06:19:20','ç³»ç»Ÿç®¡ç†å‘˜','pattern'),('aeb5ec140547417e3a92ab18431d6f0b',3,'111111.png','image/png',4351208,'/api/common/download/d86a0d17-fe96-4624-a169-35ff30830412.png',1,NULL,'active',NULL,'2026-01-22 11:39:06','2026-01-22 03:39:06','ç³»ç»Ÿç®¡ç†å‘˜','general'),('daadff4e9289305c1bd05dfbe18d2a8e',4,'生产制单-PO20260122001-ST2026012200111.pdf','application/pdf',4453852,'/api/common/download/587fd2c9-a8c7-4dde-9c6f-244606a609c1.pdf',1,NULL,'active',NULL,'2026-01-22 14:48:56','2026-01-22 06:48:55','ç³»ç»Ÿç®¡ç†å‘˜','workorder'),('e348026f575cd26e0f81f81921d25f6f',4,'111111.png','image/png',4351208,'/api/common/download/cfff93c0-1dee-4bc0-a0b4-936c9e12af49.png',1,NULL,'archived',NULL,'2026-01-22 12:36:58','2026-01-22 04:37:11','ç³»ç»Ÿç®¡ç†å‘˜','general');
/*!40000 ALTER TABLE `t_style_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_bom`
--

DROP TABLE IF EXISTS `t_style_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_bom` (
  `id` varchar(36) NOT NULL,
  `style_id` bigint NOT NULL COMMENT 'æ¬¾å·ID',
  `material_code` varchar(50) NOT NULL COMMENT 'ç‰©æ–™ç¼–ç ',
  `material_name` varchar(100) NOT NULL COMMENT 'ç‰©æ–™åç§°',
  `specification` varchar(100) DEFAULT NULL COMMENT 'è§„æ ¼',
  `color` varchar(20) DEFAULT NULL COMMENT 'é¢œè‰²',
  `unit` varchar(20) NOT NULL COMMENT 'å•ä½',
  `usage_amount` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `loss_rate` decimal(5,2) DEFAULT '0.00' COMMENT 'æŸè€—çŽ‡',
  `unit_price` decimal(10,2) DEFAULT '0.00' COMMENT 'å•ä»·',
  `total_price` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»ä»·',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `material_type` varchar(20) DEFAULT 'fabric' COMMENT '物料类型：fabric-面料，accessory-辅料',
  `supplier` varchar(100) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·BOMè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_bom`
--

LOCK TABLES `t_style_bom` WRITE;
/*!40000 ALTER TABLE `t_style_bom` DISABLE KEYS */;
INSERT INTO `t_style_bom` VALUES ('1',1,'MAT001','纯棉布料','100%纯棉','白色','米',1.5000,5.00,50.00,75.00,'2026-01-22 02:41:47','2026-01-22 03:30:36','fabric','纺织厂A',NULL,NULL),('2',1,'MAT002','拉链',NULL,'YKK金属色','条',1.0000,0.00,5.00,5.00,'2026-01-22 02:41:47','2026-01-22 03:30:36','fabric','YKK供应商',NULL,NULL),('20d16f8fec83f7a3b44eebded0d4d11b',3,'PKG-658552-09','包装袋','0','','个',1.0000,1.00,0.20,0.20,'2026-01-22 11:47:39','2026-01-22 11:50:02','accessoryE','最美布行',NULL,''),('3',1,'MAT003','纽扣','直径2cm','银色','个',6.0000,2.00,0.50,3.00,'2026-01-22 02:41:47','2026-01-22 03:30:36','fabric','五金厂B',NULL,NULL),('4ec378a36edcf573fdd45a56384dd207',3,'FAB-658552-01','主面料','150','','米',1.2500,3.00,18.00,23.18,'2026-01-22 11:47:39','2026-01-22 11:50:02','fabricA','最美布行',NULL,''),('553721dac6a8439e0cc8df6f5435d623',4,'FAB-376191-01','主面料','150','','米',1.2500,3.00,15.00,19.31,'2026-01-22 14:12:56','2026-01-22 14:19:07','fabricA','最美布行',NULL,''),('5f89e46e0ab25d4a17e20c97417cba8b',3,'INT-658552-04','衬布/粘合衬','112','','米',0.3500,3.00,5.00,1.80,'2026-01-22 11:47:39','2026-01-22 11:50:02','liningC','最美布行',NULL,''),('78a5efcfd07722031ef3e253e33df1b4',4,'BTN-376191-06','纽扣','1.5','','颗',6.0000,2.00,0.20,1.22,'2026-01-22 14:12:56','2026-01-22 14:19:07','accessoryB','最美布行',NULL,''),('7ef1e586b214bb8d02e9ce80040543ae',3,'LBL-658552-08','主唛/洗唛/尺码标','0','','套',1.0000,1.00,0.50,0.51,'2026-01-22 11:47:39','2026-01-22 11:50:02','accessoryD','最美布行',NULL,''),('87324c33aaa0ac7413a3d563d07fc500',3,'BTN-658552-06','纽扣','1.5','','颗',6.0000,2.00,2.00,12.24,'2026-01-22 11:47:39','2026-01-22 11:50:02','accessoryB','最美布行',NULL,''),('89bab1d838d161ebc4e58b56e77e6d73',4,'LBL-376191-08','主唛/洗唛/尺码标','0','','套',1.0000,1.00,0.50,0.51,'2026-01-22 14:12:56','2026-01-22 14:19:08','accessoryD','最美布行',NULL,''),('e5049a4e397a1089b01363b744a1ef46',4,'PKG-376191-09','包装袋','0','','个',1.0000,1.00,0.20,0.20,'2026-01-22 14:12:56','2026-01-22 14:19:08','accessoryE','最美布行',NULL,''),('f9605e384a97e8c17be2c5cdcb75029c',4,'INT-376191-04','衬布/粘合衬','112','','米',0.3500,3.00,7.00,2.52,'2026-01-22 14:12:56','2026-01-22 14:19:07','liningC','最美布行',NULL,'');
/*!40000 ALTER TABLE `t_style_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_info`
--

DROP TABLE IF EXISTS `t_style_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'æ¬¾å·ID',
  `style_no` varchar(50) NOT NULL COMMENT 'æ¬¾å·',
  `style_name` varchar(100) NOT NULL COMMENT 'æ¬¾å',
  `category` varchar(20) NOT NULL COMMENT 'å“ç±»ï¼šWOMAN-å¥³è£…ï¼ŒMAN-ç”·è£…ï¼ŒKID-ç«¥è£…',
  `year` int DEFAULT NULL COMMENT 'å¹´ä»½',
  `season` varchar(20) DEFAULT NULL COMMENT 'å­£èŠ‚ï¼šSPRING-æ˜¥å­£ï¼ŒSUMMER-å¤å­£ï¼ŒAUTUMN-ç§‹å­£ï¼ŒWINTER-å†¬å­£',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT 'å•ä»·',
  `cycle` int DEFAULT '0' COMMENT 'ç”Ÿäº§å‘¨æœŸ(å¤©)',
  `cover` varchar(200) DEFAULT NULL COMMENT 'å°é¢å›¾ç‰‡',
  `description` text COMMENT 'æè¿°',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `month` int DEFAULT NULL COMMENT '月份',
  `color` varchar(20) DEFAULT NULL COMMENT '颜色',
  `size` varchar(20) DEFAULT NULL COMMENT '码数',
  `pattern_status` varchar(20) DEFAULT NULL COMMENT '纸样状态：IN_PROGRESS/COMPLETED',
  `pattern_completed_time` datetime DEFAULT NULL COMMENT '纸样完成时间',
  `sample_status` varchar(20) DEFAULT NULL COMMENT '样衣状态：IN_PROGRESS/COMPLETED',
  `sample_progress` int DEFAULT '0' COMMENT '样衣进度(%)',
  `sample_completed_time` datetime DEFAULT NULL COMMENT '样衣完成时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `style_no` (`style_no`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·ä¿¡æ¯è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_info`
--

LOCK TABLES `t_style_info` WRITE;
/*!40000 ALTER TABLE `t_style_info` DISABLE KEYS */;
INSERT INTO `t_style_info` VALUES (1,'STYLE2026010001','春季连衣裙','女装',2026,'SPRING',199.00,15,NULL,'2026æ˜¥å­£æ–°æ¬¾è¿žè¡£è£™','DISABLED','2026-01-22 02:41:47','2026-01-22 11:28:35',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(2,'HHY','衬衣','女装',NULL,NULL,0.00,0,NULL,NULL,'DISABLED','2026-01-22 11:36:53','2026-01-22 11:37:03',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(3,'HYY2026012212','衬衫','女装',NULL,NULL,55.01,0,'/api/common/download/d86a0d17-fe96-4624-a169-35ff30830412.png','裁剪工艺说明：\n裁剪前需松布和缩水，确认布号、正反面及验布，裁剪按照合同订单数量明细裁剪；\n针织面料需松布24小时后可裁剪，拉布经纬纱向要求经直纬平，注意避开布匹瑕\n裁剪按纸样标注的位置点位、打刀眼对位（特殊面料和款式不可钻孔和打对位刀口），分清各部位不同用料；\n裁片按顺序编号分包，避免大货出现色差现象\n工艺说明：\n.绣花：图案颜色工艺倒顺跟版，花样不可起拱、浮线、断线、漏线、污渍、变形走样，线路过紧，线色有误，线头、纸朴需清理干净，底面需烫布朴，位置参照纸样定位。\n印花:图案需清晰,不可有重影、牙边、粘毛、露底、沙眼、粘手、发亮、龟裂、脱落，掉色,异味、呛鼻等 ，位置参照纸样定位，（胶印大货印花需做防升华处理，包装要放油光纸，防粘）\n工艺：请跟足正确版\n尺寸：请按PatPat提供的纸样与产品生产尺寸表 ,所有成品尺寸必须准确。\n用线及针距要求：全件用402#配色PP线，不可有跳线、浮线、断线疵点 .针距：3cm  14针\n主唛、 洗水唛车法及位置，请参照【PatPat 大货生产服装产品主唛、洗水唛车缝位置规范】。\n整件熨烫平服，无线毛、污渍、油渍、极光及死痕。所有线头必须清理干净。\n按照我司提供的包装与装箱方法进行包装与装箱，制作规范的装箱送货单。','DISABLED','2026-01-22 11:38:53','2026-01-22 12:36:22',NULL,NULL,NULL,'COMPLETED','2026-01-22 12:09:15',NULL,0,NULL),(4,'ST2026012200111','衬衫','女装',NULL,'SPRING',41.09,0,'/api/common/download/7ef94e5c-8999-4543-a6d9-b0280db42137.png','裁剪前需松布和缩水，确认布号、正反面及验布，裁剪按照合同订单数量明细裁剪；\n针织面料需松布24小时后可裁剪，拉布经纬纱向要求经直纬平，注意避开布匹瑕疵和色差；\n裁剪按纸样标注的位置点位、打刀眼对位（特殊面料和款式不可钻孔和打对位刀口），分清各部位不同用料；\n裁片按顺序编号分包，避免大货出现色差现象。\n\n绣花：图案颜色工艺倒顺跟PatPat版，花样不可起拱、浮线、断线、漏线、污渍、变形走样，线路过紧，线色有误，线头、纸朴需清理干净，底面需烫布朴，位置参照纸样定位。\n.印花:图案需清晰,不可有重影、牙边、粘毛、露底、沙眼、粘手、发亮、龟裂、脱落，掉色,异味、呛鼻等 ，位置参照纸样定位，（胶印大货印花需做防升华处理，包装要放油光纸，防粘\n工艺：请跟足正确版。\n尺寸：请按提供的纸样与产品生产尺寸表 ,所有成品尺寸必须准\n用线及针距要求：全件用402#配色PP线，不可有跳线、浮线、断线疵点 .针距：3cm  14针\n主唛、 洗水唛车法及位置，请参照【PatPat 大货生产服装产品主唛、洗水唛车缝位置规范】。\n整件熨烫平服，无线毛、污渍、油渍、极光及死痕。所有线头必须清理干净。\n按照我司提供的包装与装箱方法进行包装与装箱，制作规范的装箱送货单。','ENABLED','2026-01-22 12:36:47','2026-01-22 14:28:58',NULL,'格子灰色','S','COMPLETED','2026-01-22 14:27:29','COMPLETED',100,'2026-01-22 14:28:04');
/*!40000 ALTER TABLE `t_style_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_operation_log`
--

DROP TABLE IF EXISTS `t_style_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_operation_log` (
  `id` varchar(36) NOT NULL COMMENT '操作日志ID',
  `style_id` bigint NOT NULL COMMENT '款号ID',
  `biz_type` varchar(20) NOT NULL COMMENT '业务类型：sample/pattern',
  `action` varchar(50) NOT NULL COMMENT '操作动作',
  `operator` varchar(50) DEFAULT NULL COMMENT '操作人',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_style_id` (`style_id`),
  KEY `idx_biz_type` (`biz_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='款号操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_operation_log`
--

LOCK TABLES `t_style_operation_log` WRITE;
/*!40000 ALTER TABLE `t_style_operation_log` DISABLE KEYS */;
INSERT INTO `t_style_operation_log` VALUES ('0c2b00a984123cfe58b5653c4bc676fb',3,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:06'),('161d10fad6579a69d31340aaee73b8b4',4,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:24:46'),('18003d92959e55338503f360d044b657',3,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:13'),('2b0f8d5bfeea11b8c114d745fcae88b5',4,'sample','SAMPLE_COMPLETED','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:28:04'),('3fa08c6c3f72dc2f150004f74f87ffe8',3,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:11'),('48eae79342a9111ff04031dbc41bff90',3,'maintenance','SAMPLE_RESET','ç³»ç»Ÿç®¡ç†å‘˜','11','2026-01-22 12:27:58'),('4c32c70e0bd1b87718f860f9c7333706',3,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 11:55:15'),('5683a9e44e2a807667683b018dc875c4',3,'pattern','PATTERN_COMPLETED','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:15'),('5885b120f3e5e6cc56a779e57d818533',4,'sample','RECEIVE_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:27:55'),('7923e7bce7b6fe5f971b44d23a477f04',4,'style','PRODUCTION_REQUIREMENTS_SAVE','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:26:52'),('89f733fdb5b7c9f5a9d28fa0642b63f0',4,'pattern','PATTERN_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:27:19'),('b8077d16bbc678493e27f8a8daeb7a07',3,'sample','RECEIVE_START','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:25'),('bace996456e1b3673e6420266e3cdddc',4,'pattern','PATTERN_COMPLETED','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:27:29'),('d6b8d708c62b97482cdcbc7e44348316',3,'style','PRODUCTION_REQUIREMENTS_SAVE','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:08:50'),('e9e14999f2fb329e968737c4e2a0f64e',3,'sample','SAMPLE_COMPLETED','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 12:09:29');
/*!40000 ALTER TABLE `t_style_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_process`
--

DROP TABLE IF EXISTS `t_style_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_process` (
  `id` varchar(36) NOT NULL,
  `style_id` bigint NOT NULL COMMENT 'æ¬¾å·ID',
  `process_code` varchar(50) NOT NULL COMMENT 'å·¥åºç¼–ç ',
  `process_name` varchar(100) NOT NULL COMMENT 'å·¥åºåç§°',
  `sort_order` int NOT NULL DEFAULT '0',
  `work_hours` decimal(10,2) DEFAULT '0.00' COMMENT 'å·¥æ—¶',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»ä»·',
  `description` text COMMENT 'æè¿°',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `machine_type` varchar(50) DEFAULT NULL,
  `standard_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·å·¥åºè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_process`
--

LOCK TABLES `t_style_process` WRITE;
/*!40000 ALTER TABLE `t_style_process` DISABLE KEYS */;
INSERT INTO `t_style_process` VALUES ('1',1,'PROC001','è£å‰ª',1,0.50,10.00,5.00,'è£å‰ªé¢æ–™','2026-01-22 02:41:47','2026-01-22 02:41:47',NULL,0),('2',1,'PROC002','è½¦ç¼',2,2.00,15.00,30.00,'è½¦ç¼è¿žè¡£è£™','2026-01-22 02:41:47','2026-01-22 02:41:47',NULL,0),('3',1,'PROC003','æ•´çƒ«',3,0.50,8.00,4.00,'æ•´çƒ«å¤„ç†','2026-01-22 02:41:47','2026-01-22 02:41:47',NULL,0),('352ddfa60eda2c14c86bb2932222f035',3,'01','整件',1,0.00,16.00,0.00,NULL,'2026-01-22 12:04:22','2026-01-22 12:04:22','平车',0),('4',1,'PROC004','åŒ…è£…',4,0.30,5.00,1.50,'åŒ…è£…å…¥åº“','2026-01-22 02:41:47','2026-01-22 02:41:47',NULL,0),('cfa45bc860d76205391213668faf9392',4,'14','车缝',5,0.00,15.00,0.00,NULL,'2026-01-22 14:20:13','2026-01-22 14:21:01','平车',0);
/*!40000 ALTER TABLE `t_style_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_quotation`
--

DROP TABLE IF EXISTS `t_style_quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_quotation` (
  `id` varchar(36) NOT NULL,
  `style_id` bigint NOT NULL COMMENT 'æ¬¾å·ID',
  `material_cost` decimal(10,2) DEFAULT '0.00' COMMENT 'ç‰©æ–™æˆæœ¬',
  `process_cost` decimal(10,2) DEFAULT '0.00' COMMENT 'å·¥åºæˆæœ¬',
  `other_cost` decimal(10,2) DEFAULT '0.00' COMMENT 'å…¶ä»–æˆæœ¬',
  `total_cost` decimal(10,2) DEFAULT '0.00' COMMENT 'æ€»æˆæœ¬',
  `profit_rate` decimal(5,2) DEFAULT '0.00' COMMENT 'åˆ©æ¶¦çŽ‡',
  `total_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `currency` varchar(20) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `style_id` (`style_id`),
  KEY `idx_style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·æŠ¥ä»·å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_quotation`
--

LOCK TABLES `t_style_quotation` WRITE;
/*!40000 ALTER TABLE `t_style_quotation` DISABLE KEYS */;
INSERT INTO `t_style_quotation` VALUES ('1',1,83.00,40.50,10.00,133.50,50.00,199.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',NULL,NULL),('8579753e62ace0b872518ef8310057d5',4,23.76,15.00,0.00,38.76,6.00,41.09,'2026-01-22 14:28:15','2026-01-22 14:28:58',NULL,NULL),('cacbccebd4f5591887d4d1d7fde1bd62',3,37.93,16.00,0.00,53.93,2.00,55.01,'2026-01-22 12:14:53','2026-01-22 12:28:33',NULL,NULL);
/*!40000 ALTER TABLE `t_style_quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_style_size`
--

DROP TABLE IF EXISTS `t_style_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_style_size` (
  `id` varchar(36) NOT NULL,
  `style_id` bigint NOT NULL COMMENT 'æ¬¾å·ID',
  `size_name` varchar(20) NOT NULL,
  `part_name` varchar(50) NOT NULL COMMENT 'éƒ¨ä½åç§°',
  `standard_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `tolerance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sort` int NOT NULL DEFAULT '0',
  `measure_method` varchar(50) DEFAULT NULL COMMENT '度量方式',
  PRIMARY KEY (`id`),
  KEY `idx_style_id` (`style_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¬¾å·å°ºå¯¸è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_style_size`
--

LOCK TABLES `t_style_size` WRITE;
/*!40000 ALTER TABLE `t_style_size` DISABLE KEYS */;
INSERT INTO `t_style_size` VALUES ('020da3acb22643b5b002e4ac05ffa6a6',4,'XL','下摆围',104.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,5,'平量'),('0630f0eb9a65110f34de4855cc9b4cd9',4,'XXL','肩宽',47.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,2,'平量'),('0f45a85f8e01670b84600baf9610f6d2',4,'M','下摆围',96.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,5,'平量'),('1',1,'S','èƒ¸å›´',84.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('10',1,'L','è…°å›´',76.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('11',1,'L','è‡€å›´',100.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('12',1,'L','è£™é•¿',87.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('14a7616174c67ba60d6d85d2875c552a',3,'XXL','衣长',74.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,0,'平量'),('18905d03e46aa9956b84399dd496a7b9',4,'S','袖长',60.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,3,'平量'),('1ccbbebef95af0be7c1121255980acc7',4,'L','下摆围',100.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,5,'平量'),('1e652b663cd13030f098dccd4f62efb7',3,'S','袖长',60.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,3,'平量'),('2',1,'S','è…°å›´',68.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('20a2ead1de23f5dc646a66208baa608e',3,'XXL','下摆围',108.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,5,'平量'),('2106fc456de104ed23ae680d032bdddc',3,'S','胸围',96.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,1,'平量'),('22c43fd7624c2041952ab63b66494ea5',4,'S','袖口',20.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.30,4,'平量'),('264468ad6ce8126638080d8e58c3b30b',3,'S','衣长',66.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,0,'平量'),('27280d8d4b2d4a048705977c99fa5d32',3,'M','胸围',100.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,1,'平量'),('3',1,'S','è‡€å›´',92.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('3328374953a097d577ec532f36522c82',3,'L','袖长',62.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,3,'平量'),('3461e8a116371e4162f3c0b0f6f38a47',4,'XXL','袖长',64.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,3,'平量'),('390c4b793d933e898c82873f29871137',3,'M','袖长',61.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,3,'平量'),('3e10abba5b99ba7d315f81db8e74bf4a',4,'XL','袖口',23.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.30,4,'平量'),('3f3b2da92fdf2b8fabde8bf147e0382e',4,'XXL','袖口',24.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.30,4,'平量'),('4',1,'S','è£™é•¿',85.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('410fd3646934ebfa211dffa935fa042c',3,'M','袖口',21.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.30,4,'平量'),('41f2f1f6b8877c25c210590e2220b612',4,'L','袖长',62.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,3,'平量'),('450cb0870fa47661de060091e2c3bc30',3,'XXL','袖长',64.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,3,'平量'),('47bdcd254601f8fad8ce74003588b741',4,'L','肩宽',44.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,2,'平量'),('4ae2b222a174e44405aab685c55ffc78',3,'L','肩宽',44.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,2,'平量'),('4f6959bdf512c95e5b5fc0b600ae3f8d',4,'L','衣长',70.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,0,'平量'),('4fcc3f8e6f3f893e0764549b350d33fd',3,'S','袖口',20.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.30,4,'平量'),('5',1,'M','èƒ¸å›´',88.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('50bff910355d10ca962478b388db8250',3,'XXL','肩宽',47.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,2,'平量'),('519d587b93f6d9151726f035b5e9385c',4,'XXL','下摆围',108.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,5,'平量'),('597ea06a10894ad9a13b86e49c7c2f46',3,'M','衣长',68.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,0,'平量'),('5d54133f79eeda3fd5478e3312626a48',4,'XXL','胸围',112.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,1,'平量'),('5e43cd62801e4b15d8b2b14c20c1d5dd',3,'M','肩宽',42.50,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,2,'平量'),('6',1,'M','è…°å›´',72.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('662e0a2c4fbf97e008df37f94bd06cfb',3,'XL','胸围',108.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,1,'平量'),('66983748c445f651fea898b875fb7c63',4,'XXL','衣长',74.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,0,'平量'),('68551b4851d09140d9382e329264bedc',3,'S','肩宽',41.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,2,'平量'),('68c31cba8d322261b25a7781f10296fb',4,'M','肩宽',42.50,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,2,'平量'),('693ce19b61c79d3d03782227bf243484',3,'S','下摆围',92.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,5,'平量'),('6c89c00307a47baccf5e7daab04a9e2e',3,'XL','下摆围',104.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,5,'平量'),('6fe1075d01e3249672e751060c942944',3,'M','下摆围',96.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,5,'平量'),('7',1,'M','è‡€å›´',96.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('76fb300826e281dc1637ff59e31c3cf5',3,'L','袖口',22.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.30,4,'平量'),('779d83112381d7cd756ed382413985dc',4,'XL','袖长',63.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,3,'平量'),('77f53110a810be78ed655adf95db9e3b',4,'XL','胸围',108.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,1,'平量'),('7e28f401af06548937bb14055b0a2c54',4,'S','衣长',66.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,0,'平量'),('8',1,'M','è£™é•¿',86.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('875f0aa3a960c0a0f4489002af803c79',4,'S','胸围',96.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,1,'平量'),('87755a2e59be63b82d21cea32a3271f2',4,'L','袖口',22.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.30,4,'平量'),('9',1,'L','èƒ¸å›´',92.00,'2026-01-22 02:41:47','2026-01-22 02:41:47',0.00,0,NULL),('93158b53c0df7ae81981b57bc9360a78',4,'L','胸围',104.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,1,'平量'),('9c4ff4f651aef7524ed707caadac039b',4,'S','肩宽',41.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,2,'平量'),('a9883f02e36960c20a371b8917290c76',3,'XXL','胸围',112.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,1,'平量'),('aa9992613e243866d335e7528a69bd78',3,'L','下摆围',100.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,5,'平量'),('aaf738e202df1ee4c405a170eb90c02d',3,'XL','袖口',23.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.30,4,'平量'),('ae97d051d73b126532abcfbc6d1ca754',3,'XXL','袖口',24.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.30,4,'平量'),('b256485673307962627a0648a5dd5f88',3,'XL','衣长',72.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,0,'平量'),('bfba5f2c3ad4a72c0c92c360285e215f',3,'XL','肩宽',45.50,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,2,'平量'),('cba93cd73f7735144ae4baa0d407f641',3,'L','胸围',104.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,1,'平量'),('cc2a7dbceba3259d365ea9b182c44b74',4,'M','胸围',100.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,1,'平量'),('ce5889ac80020354c1a229207aea2b3b',4,'M','袖口',21.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.30,4,'平量'),('cf74866779f9fec9b99fd47ea148e32f',4,'XL','衣长',72.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,0,'平量'),('d082d0e80ea8b159b4b08bde95ca1baa',4,'M','袖长',61.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,3,'平量'),('e156f663211dbf41600c014182fa09a2',4,'S','下摆围',92.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,5,'平量'),('f53027887a0d223857c3bb7278f83e67',3,'L','衣长',70.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,0,'平量'),('f542ace696b68f4424eb496462903b04',4,'M','衣长',68.00,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,0,'平量'),('f5c837d05157af4f8287ca4d2461187a',3,'XL','袖长',63.00,'2026-01-22 12:02:18','2026-01-22 12:02:18',0.50,3,'平量'),('f931060c7effc869758c0ae8c1204cee',4,'XL','肩宽',45.50,'2026-01-22 14:19:54','2026-01-22 14:19:54',0.50,2,'平量');
/*!40000 ALTER TABLE `t_style_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_system_operation_log`
--

DROP TABLE IF EXISTS `t_system_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_system_operation_log` (
  `id` varchar(36) NOT NULL COMMENT '操作日志ID',
  `biz_type` varchar(50) NOT NULL COMMENT '业务类型',
  `biz_id` varchar(64) NOT NULL COMMENT '业务ID',
  `action` varchar(50) NOT NULL COMMENT '操作动作',
  `operator` varchar(50) DEFAULT NULL COMMENT '操作人',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_system_biz` (`biz_type`,`biz_id`),
  KEY `idx_system_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_system_operation_log`
--

LOCK TABLES `t_system_operation_log` WRITE;
/*!40000 ALTER TABLE `t_system_operation_log` DISABLE KEYS */;
INSERT INTO `t_system_operation_log` VALUES ('7aa2f81edaf2388d8f19bd597a82b918','factory','872055c6327a18338bd1c8788e4e3158','CREATE','ç³»ç»Ÿç®¡ç†å‘˜',NULL,'2026-01-22 14:45:56');
/*!40000 ALTER TABLE `t_system_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_template_library`
--

DROP TABLE IF EXISTS `t_template_library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_template_library` (
  `id` varchar(36) NOT NULL COMMENT '模板ID',
  `template_type` varchar(20) NOT NULL COMMENT '模板类型：bom/size/process/progress',
  `template_key` varchar(50) NOT NULL COMMENT '模板标识',
  `template_name` varchar(100) NOT NULL COMMENT '模板名称',
  `source_style_no` varchar(50) DEFAULT NULL COMMENT '来源款号',
  `template_content` longtext NOT NULL COMMENT '模板内容JSON',
  `locked` int NOT NULL DEFAULT '1' COMMENT '是否锁定(0:可编辑,1:已锁定)',
  `operator_name` varchar(50) DEFAULT NULL COMMENT '操作人姓名',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_key` (`template_type`,`template_key`),
  KEY `idx_type` (`template_type`),
  KEY `idx_source_style_no` (`source_style_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='模板库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_template_library`
--

LOCK TABLES `t_template_library` WRITE;
/*!40000 ALTER TABLE `t_template_library` DISABLE KEYS */;
INSERT INTO `t_template_library` VALUES ('02b82eef-0eb6-4607-8bdf-bf6223443342','progress','default','默认生产进度',NULL,'{\"nodes\":[{\"name\":\"裁剪\"},{\"name\":\"缝制\"},{\"name\":\"整烫\"},{\"name\":\"检验\"},{\"name\":\"包装\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('1b7e4d5c-65d6-488b-903b-a930c0e637fb','size','top-basic','上衣常规(国际参考)',NULL,'{\"sizes\":[\"S\",\"M\",\"L\",\"XL\",\"XXL\"],\"parts\":[{\"partName\":\"衣长\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"S\":66,\"M\":68,\"L\":70,\"XL\":72,\"XXL\":74}},{\"partName\":\"胸围\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"S\":96,\"M\":100,\"L\":104,\"XL\":108,\"XXL\":112}},{\"partName\":\"肩宽\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"S\":41,\"M\":42.5,\"L\":44,\"XL\":45.5,\"XXL\":47}},{\"partName\":\"袖长\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"S\":60,\"M\":61,\"L\":62,\"XL\":63,\"XXL\":64}},{\"partName\":\"袖口\",\"measureMethod\":\"平量\",\"tolerance\":0.3,\"values\":{\"S\":20,\"M\":21,\"L\":22,\"XL\":23,\"XXL\":24}},{\"partName\":\"下摆围\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"S\":92,\"M\":96,\"L\":100,\"XL\":104,\"XXL\":108}}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('20dadf3c-4951-4309-b53f-5a7a35156030','bom','market-jacket','通用面辅料模板(外套/夹克)',NULL,'{\"rows\":[{\"codePrefix\":\"FAB\",\"materialType\":\"fabricA\",\"materialName\":\"主面料(外套)\",\"color\":\"\",\"specification\":\"260\",\"unit\":\"米\",\"usageAmount\":1.8,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"LIN\",\"materialType\":\"liningA\",\"materialName\":\"里料\",\"color\":\"\",\"specification\":\"150\",\"unit\":\"米\",\"usageAmount\":1.4,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"INT\",\"materialType\":\"liningB\",\"materialName\":\"衬布/粘合衬\",\"color\":\"\",\"specification\":\"112\",\"unit\":\"米\",\"usageAmount\":0.6,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"ZIP\",\"materialType\":\"accessoryA\",\"materialName\":\"拉链\",\"color\":\"\",\"specification\":\"55\",\"unit\":\"条\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"BTN\",\"materialType\":\"accessoryB\",\"materialName\":\"纽扣\",\"color\":\"\",\"specification\":\"2.0\",\"unit\":\"颗\",\"usageAmount\":4,\"lossRate\":2,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"ELT\",\"materialType\":\"accessoryC\",\"materialName\":\"松紧带\",\"color\":\"\",\"specification\":\"2.0\",\"unit\":\"米\",\"usageAmount\":0.6,\"lossRate\":2,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"THR\",\"materialType\":\"accessoryD\",\"materialName\":\"缝纫线\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"卷\",\"usageAmount\":0.03,\"lossRate\":5,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"PKG\",\"materialType\":\"accessoryE\",\"materialName\":\"包装袋\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"个\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('37e4f681-35c1-418a-afaf-690284602828','size','pants-basic','裤装常规(国际参考)',NULL,'{\"sizes\":[\"28\",\"29\",\"30\",\"31\",\"32\",\"33\",\"34\"],\"parts\":[{\"partName\":\"裤长\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"28\":98,\"29\":100,\"30\":102,\"31\":104,\"32\":106,\"33\":108,\"34\":110}},{\"partName\":\"腰围\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"28\":72,\"29\":74.5,\"30\":77,\"31\":79.5,\"32\":82,\"33\":84.5,\"34\":87}},{\"partName\":\"臀围\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"28\":94,\"29\":96.5,\"30\":99,\"31\":101.5,\"32\":104,\"33\":106.5,\"34\":109}},{\"partName\":\"大腿围\",\"measureMethod\":\"平量\",\"tolerance\":0.5,\"values\":{\"28\":56,\"29\":57,\"30\":58,\"31\":59,\"32\":60,\"33\":61,\"34\":62}},{\"partName\":\"脚口\",\"measureMethod\":\"平量\",\"tolerance\":0.3,\"values\":{\"28\":34,\"29\":35,\"30\":36,\"31\":37,\"32\":38,\"33\":39,\"34\":40}},{\"partName\":\"前浪\",\"measureMethod\":\"平量\",\"tolerance\":0.3,\"values\":{\"28\":25,\"29\":25.5,\"30\":26,\"31\":26.5,\"32\":27,\"33\":27.5,\"34\":28}},{\"partName\":\"后浪\",\"measureMethod\":\"平量\",\"tolerance\":0.3,\"values\":{\"28\":35,\"29\":35.5,\"30\":36,\"31\":36.5,\"32\":37,\"33\":37.5,\"34\":38}}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('399926fd-920c-4e23-a63a-5b7c389b744e','process','style_ST2026012200111','ST2026012200111-工艺模板','ST2026012200111','{\"steps\":[{\"processCode\":\"14\",\"processName\":\"车缝\",\"machineType\":\"平车\",\"price\":15.00,\"standardTime\":0}]}',1,NULL,'2026-01-22 12:36:48','2026-01-22 14:21:01'),('596d1f72-c778-4726-b71e-d127c4f64ac3','bom','market-knit','通用面辅料模板(针织/卫衣)',NULL,'{\"rows\":[{\"codePrefix\":\"FAB\",\"materialType\":\"fabricA\",\"materialName\":\"主面料(针织)\",\"color\":\"\",\"specification\":\"180\",\"unit\":\"米\",\"usageAmount\":1.15,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"RIB\",\"materialType\":\"fabricB\",\"materialName\":\"罗纹(领口/袖口/下摆)\",\"color\":\"\",\"specification\":\"100\",\"unit\":\"米\",\"usageAmount\":0.25,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"THR\",\"materialType\":\"accessoryA\",\"materialName\":\"缝纫线\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"卷\",\"usageAmount\":0.02,\"lossRate\":5,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"LBL\",\"materialType\":\"accessoryB\",\"materialName\":\"主唛/洗唛/尺码标\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"套\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"PKG\",\"materialType\":\"accessoryC\",\"materialName\":\"包装袋\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"个\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('794fca32-0aba-4bba-8643-c791334c2441','process','style_HYY2026012212','HYY2026012212-工艺模板','HYY2026012212','{\"steps\":[{\"processCode\":\"01\",\"processName\":\"整件\",\"machineType\":\"平车\",\"price\":16.00,\"standardTime\":0}]}',1,NULL,'2026-01-22 11:38:53','2026-01-22 12:04:22'),('7b26844f-19f7-499d-ab4c-b8f5a9d69cb1','size','kids-basic','童装常规(国际参考)',NULL,'{\"sizes\":[\"90\",\"100\",\"110\",\"120\",\"130\",\"140\",\"150\"],\"parts\":[{\"partName\":\"衣长\",\"measureMethod\":\"平量\",\"tolerance\":0.7,\"values\":{\"90\":38,\"100\":42,\"110\":46,\"120\":50,\"130\":54,\"140\":58,\"150\":62}},{\"partName\":\"胸围\",\"measureMethod\":\"平量\",\"tolerance\":0.7,\"values\":{\"90\":62,\"100\":66,\"110\":70,\"120\":74,\"130\":78,\"140\":82,\"150\":86}},{\"partName\":\"肩宽\",\"measureMethod\":\"平量\",\"tolerance\":0.7,\"values\":{\"90\":26,\"100\":27.5,\"110\":29,\"120\":30.5,\"130\":32,\"140\":33.5,\"150\":35}},{\"partName\":\"袖长\",\"measureMethod\":\"平量\",\"tolerance\":0.7,\"values\":{\"90\":32,\"100\":35,\"110\":38,\"120\":41,\"130\":44,\"140\":47,\"150\":50}}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('7cd98df7-4247-4b42-9a87-fb6203cc063b','process','basic','基础工序',NULL,'{\"steps\":[{\"processCode\":\"01\",\"processName\":\"裁剪\",\"machineType\":\"\"},{\"processCode\":\"02\",\"processName\":\"缝制\",\"machineType\":\"\"},{\"processCode\":\"03\",\"processName\":\"整烫\",\"machineType\":\"\"},{\"processCode\":\"04\",\"processName\":\"检验\",\"machineType\":\"\"},{\"processCode\":\"05\",\"processName\":\"包装\",\"machineType\":\"\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('a5b72a38-61e6-4b12-9af3-846850ed12d7','progress','style_ST2026012200111','ST2026012200111-进度模板','ST2026012200111','{\"nodes\":[{\"name\":\"车缝\",\"unitPrice\":15.00}]}',1,NULL,'2026-01-22 12:36:48','2026-01-22 14:21:01'),('af538317-f784-463f-8c98-698f1cbcf8d6','process','knit-top','针织上衣(常用)',NULL,'{\"steps\":[{\"processCode\":\"10\",\"processName\":\"上领\",\"machineType\":\"平车\"},{\"processCode\":\"11\",\"processName\":\"上袖\",\"machineType\":\"平车\"},{\"processCode\":\"12\",\"processName\":\"侧缝\",\"machineType\":\"拷边\"},{\"processCode\":\"13\",\"processName\":\"下摆\",\"machineType\":\"绷缝\"},{\"processCode\":\"14\",\"processName\":\"袖口\",\"machineType\":\"绷缝\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('b46613fd-ca5a-43d6-910f-c2ec6eb9693b','progress','style_HYY2026012212','HYY2026012212-进度模板','HYY2026012212','{\"nodes\":[{\"name\":\"整件\",\"unitPrice\":16.00}]}',1,NULL,'2026-01-22 11:38:53','2026-01-22 12:04:22'),('bab1eecc-cfe2-4335-8744-f97f1829dbdf','bom','market-basic','通用面辅料模板(市面常用)',NULL,'{\"rows\":[{\"codePrefix\":\"FAB\",\"materialType\":\"fabricA\",\"materialName\":\"主面料\",\"color\":\"\",\"specification\":\"150\",\"unit\":\"米\",\"usageAmount\":1.25,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"LIN\",\"materialType\":\"liningA\",\"materialName\":\"里料\",\"color\":\"\",\"specification\":\"150\",\"unit\":\"米\",\"usageAmount\":0.85,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"POC\",\"materialType\":\"liningB\",\"materialName\":\"口袋布\",\"color\":\"\",\"specification\":\"90\",\"unit\":\"米\",\"usageAmount\":0.15,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"INT\",\"materialType\":\"liningC\",\"materialName\":\"衬布/粘合衬\",\"color\":\"\",\"specification\":\"112\",\"unit\":\"米\",\"usageAmount\":0.35,\"lossRate\":3,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"ZIP\",\"materialType\":\"accessoryA\",\"materialName\":\"拉链\",\"color\":\"\",\"specification\":\"18\",\"unit\":\"条\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"BTN\",\"materialType\":\"accessoryB\",\"materialName\":\"纽扣\",\"color\":\"\",\"specification\":\"1.5\",\"unit\":\"颗\",\"usageAmount\":6,\"lossRate\":2,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"THR\",\"materialType\":\"accessoryC\",\"materialName\":\"缝纫线\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"卷\",\"usageAmount\":0.02,\"lossRate\":5,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"LBL\",\"materialType\":\"accessoryD\",\"materialName\":\"主唛/洗唛/尺码标\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"套\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"},{\"codePrefix\":\"PKG\",\"materialType\":\"accessoryE\",\"materialName\":\"包装袋\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"个\",\"usageAmount\":1,\"lossRate\":1,\"unitPrice\":0,\"supplier\":\"\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16'),('c3c5a1f4-2931-4efd-8c16-08696fef05e7','size','style_HYY2026012212','HYY2026012212-尺码模板','HYY2026012212','{\"sizes\":[],\"parts\":[]}',1,NULL,'2026-01-22 11:38:53','2026-01-22 11:38:53'),('d47ae0e9-1db8-41be-92f6-ed0850626704','size','style_ST2026012200111','ST2026012200111-尺码模板','ST2026012200111','{\"sizes\":[],\"parts\":[]}',1,NULL,'2026-01-22 12:36:48','2026-01-22 12:36:48'),('e35d7179-5d23-4e56-8944-cc5aeab104f2','bom','style_ST2026012200111','ST2026012200111-BOM模板','ST2026012200111','{\"rows\":[{\"materialType\":\"fabricA\",\"materialName\":\"主面料\",\"color\":\"\",\"specification\":\"150\",\"unit\":\"米\",\"usageAmount\":1.2500,\"lossRate\":3.00,\"unitPrice\":15.00,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"accessoryB\",\"materialName\":\"纽扣\",\"color\":\"\",\"specification\":\"1.5\",\"unit\":\"颗\",\"usageAmount\":6.0000,\"lossRate\":2.00,\"unitPrice\":0.20,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"accessoryD\",\"materialName\":\"主唛/洗唛/尺码标\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"套\",\"usageAmount\":1.0000,\"lossRate\":1.00,\"unitPrice\":0.50,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"accessoryE\",\"materialName\":\"包装袋\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"个\",\"usageAmount\":1.0000,\"lossRate\":1.00,\"unitPrice\":0.20,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"liningC\",\"materialName\":\"衬布/粘合衬\",\"color\":\"\",\"specification\":\"112\",\"unit\":\"米\",\"usageAmount\":0.3500,\"lossRate\":3.00,\"unitPrice\":7.00,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"}]}',1,NULL,'2026-01-22 12:36:48','2026-01-22 14:19:08'),('e806f0fd-b2d8-492d-8293-91d20f60fda2','process_price','style_HYY2026012212','HYY2026012212-工序单价模板','HYY2026012212','{\"steps\":[{\"processCode\":\"01\",\"processName\":\"整件\",\"unitPrice\":16.00}]}',1,NULL,'2026-01-22 11:38:53','2026-01-22 12:04:22'),('ecff7861-ab0d-4d7a-9314-491c7d46c8a7','bom','style_HYY2026012212','HYY2026012212-BOM模板','HYY2026012212','{\"rows\":[{\"materialType\":\"accessoryE\",\"materialName\":\"包装袋\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"个\",\"usageAmount\":1.0000,\"lossRate\":1.00,\"unitPrice\":0.20,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"fabricA\",\"materialName\":\"主面料\",\"color\":\"\",\"specification\":\"150\",\"unit\":\"米\",\"usageAmount\":1.2500,\"lossRate\":3.00,\"unitPrice\":18.00,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"liningC\",\"materialName\":\"衬布/粘合衬\",\"color\":\"\",\"specification\":\"112\",\"unit\":\"米\",\"usageAmount\":0.3500,\"lossRate\":3.00,\"unitPrice\":5.00,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"accessoryD\",\"materialName\":\"主唛/洗唛/尺码标\",\"color\":\"\",\"specification\":\"0\",\"unit\":\"套\",\"usageAmount\":1.0000,\"lossRate\":1.00,\"unitPrice\":0.50,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"},{\"materialType\":\"accessoryB\",\"materialName\":\"纽扣\",\"color\":\"\",\"specification\":\"1.5\",\"unit\":\"颗\",\"usageAmount\":6.0000,\"lossRate\":2.00,\"unitPrice\":2.00,\"supplier\":\"最美布行\",\"codePrefix\":\"MAT\"}]}',1,NULL,'2026-01-22 11:38:53','2026-01-22 11:50:02'),('ef8388da-fa18-45c8-80f8-b24583795fbe','process_price','style_ST2026012200111','ST2026012200111-工序单价模板','ST2026012200111','{\"steps\":[{\"processName\":\"车缝\",\"unitPrice\":15}]}',1,'系统管理员','2026-01-22 12:36:48','2026-01-22 17:04:17'),('feb9bba8-92b7-419d-844d-9c593916539c','process','woven-shirt','梭织衬衫(常用)',NULL,'{\"steps\":[{\"processCode\":\"20\",\"processName\":\"做领\",\"machineType\":\"平车\"},{\"processCode\":\"21\",\"processName\":\"上领\",\"machineType\":\"平车\"},{\"processCode\":\"22\",\"processName\":\"做门襟\",\"machineType\":\"平车\"},{\"processCode\":\"23\",\"processName\":\"上袖\",\"machineType\":\"平车\"},{\"processCode\":\"24\",\"processName\":\"锁眼\",\"machineType\":\"锁眼机\"},{\"processCode\":\"25\",\"processName\":\"钉扣\",\"machineType\":\"钉扣机\"}]}',1,NULL,'2026-01-22 02:42:16','2026-01-22 02:42:16');
/*!40000 ALTER TABLE `t_template_library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_template_operation_log`
--

DROP TABLE IF EXISTS `t_template_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_template_operation_log` (
  `id` varchar(36) NOT NULL COMMENT '操作日志ID',
  `template_id` varchar(36) NOT NULL COMMENT '模板ID',
  `action` varchar(50) NOT NULL COMMENT '操作动作',
  `operator` varchar(50) DEFAULT NULL COMMENT '操作人',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_template_id` (`template_id`),
  KEY `idx_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='模板操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_template_operation_log`
--

LOCK TABLES `t_template_operation_log` WRITE;
/*!40000 ALTER TABLE `t_template_operation_log` DISABLE KEYS */;
INSERT INTO `t_template_operation_log` VALUES ('3e8a3376bd09bf226240bcd5be09d5db','ef8388da-fa18-45c8-80f8-b24583795fbe','ROLLBACK','系统管理员','单价','2026-01-22 16:35:09'),('41f5dadbe56fc41ea8c5851ddc68379a','ef8388da-fa18-45c8-80f8-b24583795fbe','ROLLBACK','系统管理员','111','2026-01-22 16:53:38'),('612454a76d4154ac49a4be7a0f93e1b9','ef8388da-fa18-45c8-80f8-b24583795fbe','ROLLBACK','系统管理员','11','2026-01-22 16:50:45'),('92ce34e9f7e70bd0cd3235b3c25af324','ef8388da-fa18-45c8-80f8-b24583795fbe','ROLLBACK','系统管理员','11','2026-01-22 17:02:52');
/*!40000 ALTER TABLE `t_template_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ç”¨æˆ·ID',
  `username` varchar(50) NOT NULL COMMENT 'ç”¨æˆ·å',
  `password` varchar(100) NOT NULL COMMENT 'å¯†ç ',
  `name` varchar(50) NOT NULL COMMENT 'å§“å',
  `role_id` bigint DEFAULT NULL COMMENT 'è§’è‰²ID',
  `role_name` varchar(50) DEFAULT NULL COMMENT 'è§’è‰²åç§°',
  `permission_range` varchar(50) DEFAULT NULL COMMENT 'æƒé™èŒƒå›´',
  `status` varchar(20) DEFAULT 'ENABLED' COMMENT 'çŠ¶æ€ï¼šENABLED-å¯ç”¨ï¼ŒDISABLED-ç¦ç”¨',
  `approval_status` varchar(20) DEFAULT 'approved' COMMENT 'å®¡æ‰¹çŠ¶æ€: pending, approved, rejected',
  `approval_time` datetime DEFAULT NULL COMMENT 'å®¡æ‰¹æ—¶é—´',
  `approval_remark` varchar(500) DEFAULT NULL COMMENT 'å®¡æ‰¹å¤‡æ³¨',
  `phone` varchar(20) DEFAULT NULL COMMENT 'ç”µè¯',
  `email` varchar(50) DEFAULT NULL COMMENT 'é‚®ç®±',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `last_login_time` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `last_login_ip` varchar(20) DEFAULT NULL COMMENT 'æœ€åŽç™»å½•IP',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç”¨æˆ·è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,'admin','$2a$10$0sEa7CZjCKt.FTSDslzRE.d9zEe47vg0mxSOIJCgJTyPW2mutHjUO','系统管理员',1,'admin','all','ENABLED','approved',NULL,NULL,NULL,NULL,'2026-01-22 02:41:47','2026-01-22 03:14:26',NULL,NULL);
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_production_order_flow_stage_snapshot`
--

DROP TABLE IF EXISTS `v_production_order_flow_stage_snapshot`;
/*!50001 DROP VIEW IF EXISTS `v_production_order_flow_stage_snapshot`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_production_order_flow_stage_snapshot` AS SELECT 
 1 AS `order_id`,
 1 AS `order_start_time`,
 1 AS `order_end_time`,
 1 AS `order_operator_name`,
 1 AS `procurement_scan_end_time`,
 1 AS `procurement_scan_operator_name`,
 1 AS `cutting_start_time`,
 1 AS `cutting_end_time`,
 1 AS `cutting_operator_name`,
 1 AS `cutting_quantity`,
 1 AS `sewing_start_time`,
 1 AS `sewing_end_time`,
 1 AS `sewing_operator_name`,
 1 AS `quality_start_time`,
 1 AS `quality_end_time`,
 1 AS `quality_operator_name`,
 1 AS `quality_quantity`,
 1 AS `warehousing_start_time`,
 1 AS `warehousing_end_time`,
 1 AS `warehousing_operator_name`,
 1 AS `warehousing_quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_production_order_procurement_snapshot`
--

DROP TABLE IF EXISTS `v_production_order_procurement_snapshot`;
/*!50001 DROP VIEW IF EXISTS `v_production_order_procurement_snapshot`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_production_order_procurement_snapshot` AS SELECT 
 1 AS `order_id`,
 1 AS `procurement_start_time`,
 1 AS `procurement_end_time`,
 1 AS `procurement_operator_name`,
 1 AS `purchase_quantity`,
 1 AS `arrived_quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_production_order_stage_done_agg`
--

DROP TABLE IF EXISTS `v_production_order_stage_done_agg`;
/*!50001 DROP VIEW IF EXISTS `v_production_order_stage_done_agg`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_production_order_stage_done_agg` AS SELECT 
 1 AS `order_id`,
 1 AS `stage_name`,
 1 AS `done_quantity`,
 1 AS `last_scan_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_production_order_flow_stage_snapshot`
--

/*!50001 DROP VIEW IF EXISTS `v_production_order_flow_stage_snapshot`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_production_order_flow_stage_snapshot` AS select `sr`.`order_id` AS `order_id`,min((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) = '下单')) then `sr`.`scan_time` end)) AS `order_start_time`,max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) = '下单')) then `sr`.`scan_time` end)) AS `order_end_time`,substring_index(max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) = '下单')) then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `order_operator_name`,max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) = '采购')) then `sr`.`scan_time` end)) AS `procurement_scan_end_time`,substring_index(max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) = '采购')) then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `procurement_scan_operator_name`,min((case when (`sr`.`scan_type` = 'cutting') then `sr`.`scan_time` end)) AS `cutting_start_time`,max((case when (`sr`.`scan_type` = 'cutting') then `sr`.`scan_time` end)) AS `cutting_end_time`,substring_index(max((case when (`sr`.`scan_type` = 'cutting') then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `cutting_operator_name`,sum((case when (`sr`.`scan_type` = 'cutting') then ifnull(`sr`.`quantity`,0) else 0 end)) AS `cutting_quantity`,min((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) not in ('下单','采购')) and (ifnull(`sr`.`process_code`,'') <> 'quality_warehousing') and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')))) then `sr`.`scan_time` end)) AS `sewing_start_time`,max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) not in ('下单','采购')) and (ifnull(`sr`.`process_code`,'') <> 'quality_warehousing') and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')))) then `sr`.`scan_time` end)) AS `sewing_end_time`,substring_index(max((case when ((`sr`.`scan_type` = 'production') and (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) not in ('下单','采购')) and (ifnull(`sr`.`process_code`,'') <> 'quality_warehousing') and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%'))) and (not((coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')))) then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `sewing_operator_name`,min((case when ((`sr`.`scan_type` = 'quality') or (ifnull(`sr`.`process_code`,'') = 'quality_warehousing') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')) then `sr`.`scan_time` end)) AS `quality_start_time`,max((case when ((`sr`.`scan_type` = 'quality') or (ifnull(`sr`.`process_code`,'') = 'quality_warehousing') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')) then `sr`.`scan_time` end)) AS `quality_end_time`,substring_index(max((case when ((`sr`.`scan_type` = 'quality') or (ifnull(`sr`.`process_code`,'') = 'quality_warehousing') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')) then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `quality_operator_name`,sum((case when ((`sr`.`scan_type` = 'quality') or (ifnull(`sr`.`process_code`,'') = 'quality_warehousing') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%质检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%检验%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%品检%') or (coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) like '%验货%')) then ifnull(`sr`.`quantity`,0) else 0 end)) AS `quality_quantity`,min((case when ((`sr`.`scan_type` = 'warehouse') and (ifnull(`sr`.`process_code`,'') <> 'warehouse_rollback')) then `sr`.`scan_time` end)) AS `warehousing_start_time`,max((case when ((`sr`.`scan_type` = 'warehouse') and (ifnull(`sr`.`process_code`,'') <> 'warehouse_rollback')) then `sr`.`scan_time` end)) AS `warehousing_end_time`,substring_index(max((case when ((`sr`.`scan_type` = 'warehouse') and (ifnull(`sr`.`process_code`,'') <> 'warehouse_rollback')) then concat(lpad(unix_timestamp(`sr`.`scan_time`),20,'0'),lpad(unix_timestamp(`sr`.`create_time`),20,'0'),'|',ifnull(`sr`.`operator_name`,'')) end)),'|',-(1)) AS `warehousing_operator_name`,sum((case when ((`sr`.`scan_type` = 'warehouse') and (ifnull(`sr`.`process_code`,'') <> 'warehouse_rollback')) then ifnull(`sr`.`quantity`,0) else 0 end)) AS `warehousing_quantity` from `t_scan_record` `sr` where (`sr`.`scan_result` = 'success') group by `sr`.`order_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_production_order_procurement_snapshot`
--

/*!50001 DROP VIEW IF EXISTS `v_production_order_procurement_snapshot`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_production_order_procurement_snapshot` AS select `p`.`order_id` AS `order_id`,min(`p`.`create_time`) AS `procurement_start_time`,max(coalesce(`p`.`received_time`,`p`.`update_time`)) AS `procurement_end_time`,substring_index(max(concat(lpad(unix_timestamp(coalesce(`p`.`received_time`,`p`.`update_time`)),20,'0'),lpad(unix_timestamp(`p`.`update_time`),20,'0'),'|',ifnull(`p`.`receiver_name`,''))),'|',-(1)) AS `procurement_operator_name`,sum(ifnull(`p`.`purchase_quantity`,0)) AS `purchase_quantity`,sum(ifnull(`p`.`arrived_quantity`,0)) AS `arrived_quantity` from `t_material_purchase` `p` where ((`p`.`delete_flag` = 0) and (`p`.`order_id` is not null) and (`p`.`order_id` <> '')) group by `p`.`order_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_production_order_stage_done_agg`
--

/*!50001 DROP VIEW IF EXISTS `v_production_order_stage_done_agg`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_production_order_stage_done_agg` AS select `t`.`order_id` AS `order_id`,`t`.`stage_name` AS `stage_name`,sum(ifnull(`t`.`quantity`,0)) AS `done_quantity`,max(`t`.`scan_time`) AS `last_scan_time` from (select `sr`.`order_id` AS `order_id`,coalesce(nullif(trim(`sr`.`progress_stage`),''),nullif(trim(`sr`.`process_name`),'')) AS `stage_name`,`sr`.`quantity` AS `quantity`,`sr`.`scan_time` AS `scan_time` from `t_scan_record` `sr` where ((`sr`.`scan_result` = 'success') and (`sr`.`quantity` > 0) and (`sr`.`scan_type` in ('production','cutting')))) `t` where ((`t`.`stage_name` is not null) and (`t`.`stage_name` <> '')) group by `t`.`order_id`,`t`.`stage_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-22 12:13:55
