package com.fashion.supplychain.production.controller;

import com.fashion.supplychain.common.Result;
import com.fashion.supplychain.production.entity.ScanRecord;
import com.fashion.supplychain.production.orchestration.ScanRecordOrchestrator;
import com.fashion.supplychain.production.service.SKUService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.List;

/**
 * 扫码记录Controller
 */
@RestController
@RequestMapping("/api/production/scan")
public class ScanRecordController {

    @Autowired
    private ScanRecordOrchestrator scanRecordOrchestrator;

    // ✅ Phase 3新增: SKU服务注入
    @Autowired
    private SKUService skuService;

    /**
     * 执行扫码操作
     */
    @PostMapping("/execute")
    public Result<?> execute(@RequestBody Map<String, Object> params) {
        return Result.success(scanRecordOrchestrator.execute(params));
    }

    @PostMapping("/unit-price")
    public Result<?> resolveUnitPrice(@RequestBody Map<String, Object> params) {
        return Result.success(scanRecordOrchestrator.resolveUnitPrice(params));
    }

    @PostMapping("/undo")
    public Result<?> undo(@RequestBody Map<String, Object> params) {
        return Result.success(scanRecordOrchestrator.undo(params));
    }

    /**
     * 【新版统一查询】分页查询扫码记录
     * 支持参数：
     * - orderId: 按订单ID查询
     * - styleNo: 按款号查询
     * - currentUser: 查询当前用户记录（值为true）
     * - scanType/startTime/endTime/orderNo/bundleNo/workerName/operatorName
     *
     * @since 2026-02-01 优化版本
     */
    @GetMapping("/list")
    public Result<?> list(@RequestParam Map<String, Object> params) {
        // 智能路由：根据参数自动选择查询方法
        if (params.containsKey("orderId")) {
            String orderId = params.get("orderId").toString();
            int page = params.containsKey("page") ? Integer.parseInt(params.get("page").toString()) : 1;
            int pageSize = params.containsKey("pageSize") ? Integer.parseInt(params.get("pageSize").toString()) : 10;
            return Result.success(scanRecordOrchestrator.getByOrderId(orderId, page, pageSize));
        }

        if (params.containsKey("styleNo")) {
            String styleNo = params.get("styleNo").toString();
            int page = params.containsKey("page") ? Integer.parseInt(params.get("page").toString()) : 1;
            int pageSize = params.containsKey("pageSize") ? Integer.parseInt(params.get("pageSize").toString()) : 10;
            return Result.success(scanRecordOrchestrator.getByStyleNo(styleNo, page, pageSize));
        }

        if (params.containsKey("currentUser") && "true".equals(params.get("currentUser").toString())) {
            int page = params.containsKey("page") ? Integer.parseInt(params.get("page").toString()) : 1;
            int pageSize = params.containsKey("pageSize") ? Integer.parseInt(params.get("pageSize").toString()) : 10;
            String scanType = params.containsKey("scanType") ? params.get("scanType").toString() : null;
            String startTime = params.containsKey("startTime") ? params.get("startTime").toString() : null;
            String endTime = params.containsKey("endTime") ? params.get("endTime").toString() : null;
            String orderNo = params.containsKey("orderNo") ? params.get("orderNo").toString() : null;
            String bundleNo = params.containsKey("bundleNo") ? params.get("bundleNo").toString() : null;
            String workerName = params.containsKey("workerName") ? params.get("workerName").toString() : null;
            String operatorName = params.containsKey("operatorName") ? params.get("operatorName").toString() : null;
            return Result.success(scanRecordOrchestrator.getMyHistory(
                page, pageSize, scanType, startTime, endTime, orderNo, bundleNo, workerName, operatorName));
        }

        // 默认分页查询
        IPage<ScanRecord> pageResult = scanRecordOrchestrator.list(params);
        return Result.success(pageResult);
    }

    /**
     * @deprecated 已废弃，请使用 GET /list?orderId={orderId}
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/order/{orderId}")
    public Result<?> getByOrderId(@PathVariable String orderId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("orderId", orderId);
        params.put("page", page);
        params.put("pageSize", pageSize);
        return list(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /list?styleNo={styleNo}
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/style/{styleNo}")
    public Result<?> getByStyleNo(@PathVariable String styleNo,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("styleNo", styleNo);
        params.put("page", page);
        params.put("pageSize", pageSize);
        return list(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /list（功能相同）
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/history")
    public Result<?> getHistory(@RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("page", page);
        params.put("pageSize", pageSize);
        return list(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /list?currentUser=true
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/my-history")
    public Result<?> getMyHistory(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String scanType,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime,
            @RequestParam(required = false) String orderNo,
            @RequestParam(required = false) String bundleNo,
            @RequestParam(required = false) String workerName,
            @RequestParam(required = false) String operatorName) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("currentUser", "true");
        params.put("page", page);
        params.put("pageSize", pageSize);
        if (scanType != null) params.put("scanType", scanType);
        if (startTime != null) params.put("startTime", startTime);
        if (endTime != null) params.put("endTime", endTime);
        if (orderNo != null) params.put("orderNo", orderNo);
        if (bundleNo != null) params.put("bundleNo", bundleNo);
        if (workerName != null) params.put("workerName", workerName);
        if (operatorName != null) params.put("operatorName", operatorName);
        return list(params);
    }

    @GetMapping("/personal-stats")
    public Result<?> personalStats(@RequestParam(required = false) String scanType) {
        return Result.success(scanRecordOrchestrator.getPersonalStats(scanType));
    }

    @PostMapping("/cleanup")
    public Result<?> cleanup(@RequestParam(required = false) String from) {
        return Result.success(scanRecordOrchestrator.cleanup(from));
    }

    /**
     * 获取我的质检待处理任务（已领取未确认结果）
     */
    @GetMapping("/my-quality-tasks")
    public Result<?> getMyQualityTasks() {
        return Result.success(scanRecordOrchestrator.getMyQualityTasks());
    }

    @PostMapping("/delete-full-link/{orderId}")
    public Result<?> deleteFullLinkByOrderId(@PathVariable String orderId) {
        return Result.success(scanRecordOrchestrator.deleteFullLinkByOrderId(orderId));
    }

    // ================= ✅ SKU相关端点（2026-02-01优化版本）=================

    /**
     * 【新版统一SKU查询】
     * 支持参数：
     * - type: list/progress/order-progress/statistics/is-completed/report
     * - orderNo: 订单号（必填）
     * - styleNo, color, size: SKU维度（progress/is-completed时需要）
     *
     * 示例：
     * - GET /sku/query?type=list&orderNo=PO001
     * - GET /sku/query?type=progress&orderNo=PO001&styleNo=ST001&color=黑色&size=L
     *
     * @since 2026-02-01 优化版本
     */
    @GetMapping("/sku/query")
    public Result<?> querySKU(@RequestParam Map<String, Object> params) {
        String type = params.containsKey("type") ? params.get("type").toString() : "list";
        String orderNo = params.containsKey("orderNo") ? params.get("orderNo").toString() : null;

        if (orderNo == null) {
            return Result.fail("缺少orderNo参数");
        }

        switch (type) {
            case "list":
                return Result.success(skuService.getSKUListByOrder(orderNo));

            case "progress":
                String styleNo = params.containsKey("styleNo") ? params.get("styleNo").toString() : null;
                String color = params.containsKey("color") ? params.get("color").toString() : null;
                String size = params.containsKey("size") ? params.get("size").toString() : null;
                if (styleNo == null || color == null || size == null) {
                    return Result.fail("缺少SKU维度参数（styleNo/color/size）");
                }
                return Result.success(skuService.getSKUProgress(orderNo, styleNo, color, size));

            case "order-progress":
                return Result.success(skuService.getOrderSKUProgress(orderNo));

            case "statistics":
                return Result.success(skuService.querySKUStatistics(params));

            case "is-completed":
                String styleNo2 = params.containsKey("styleNo") ? params.get("styleNo").toString() : null;
                String color2 = params.containsKey("color") ? params.get("color").toString() : null;
                String size2 = params.containsKey("size") ? params.get("size").toString() : null;
                if (styleNo2 == null || color2 == null || size2 == null) {
                    return Result.fail("缺少SKU维度参数（styleNo/color/size）");
                }
                boolean completed = skuService.isSKUCompleted(orderNo, styleNo2, color2, size2);
                return Result.success(completed);

            case "report":
                return Result.success(skuService.generateSKUReport(orderNo));

            default:
                return Result.fail("不支持的查询类型：" + type);
        }
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=list&orderNo={orderNo}
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/list/{orderNo}")
    public Result<?> getSKUList(@PathVariable String orderNo) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("type", "list");
        params.put("orderNo", orderNo);
        return querySKU(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=progress&...
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/progress")
    public Result<?> getSKUProgress(
            @RequestParam String orderNo,
            @RequestParam String styleNo,
            @RequestParam String color,
            @RequestParam String size) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("type", "progress");
        params.put("orderNo", orderNo);
        params.put("styleNo", styleNo);
        params.put("color", color);
        params.put("size", size);
        return querySKU(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=order-progress&orderNo={orderNo}
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/order-progress/{orderNo}")
    public Result<?> getOrderSKUProgress(@PathVariable String orderNo) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("type", "order-progress");
        params.put("orderNo", orderNo);
        return querySKU(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=statistics&...
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/statistics")
    public Result<?> querySKUStatistics(@RequestParam Map<String, Object> params) {
        params.put("type", "statistics");
        return querySKU(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=is-completed&...
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/is-completed")
    public Result<?> isSKUCompleted(
            @RequestParam String orderNo,
            @RequestParam String styleNo,
            @RequestParam String color,
            @RequestParam String size) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("type", "is-completed");
        params.put("orderNo", orderNo);
        params.put("styleNo", styleNo);
        params.put("color", color);
        params.put("size", size);
        return querySKU(params);
    }

    /**
     * @deprecated 已废弃，请使用 GET /sku/query?type=report&orderNo={orderNo}
     * @since 2026-02-01 标记废弃，将在2026-05-01删除
     */
    @Deprecated
    @GetMapping("/sku/report/{orderNo}")
    public Result<?> generateSKUReport(@PathVariable String orderNo) {
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("type", "report");
        params.put("orderNo", orderNo);
        return querySKU(params);
    }

    /**
     * 检测扫码模式
     */
    @PostMapping("/sku/detect-mode")
    public Result<?> detectScanMode(@RequestBody Map<String, Object> params) {
        String scanCode = (String) params.get("scanCode");
        String color = (String) params.get("color");
        String size = (String) params.get("size");
        String mode = skuService.detectScanMode(scanCode, color, size);
        return Result.success(mode);
    }

    /**
     * 验证SKU数据
     */
    @PostMapping("/sku/validate")
    public Result<?> validateSKU(@RequestBody ScanRecord scanRecord) {
        boolean valid = skuService.validateSKU(scanRecord);
        return Result.success(valid);
    }

    /**
     * 获取订单的工序单价配置（Phase 5新增）
     */
    @GetMapping("/process-prices/{orderNo}")
    public Result<?> getProcessUnitPrices(@PathVariable String orderNo) {
        List<Map<String, Object>> prices = skuService.getProcessUnitPrices(orderNo);
        return Result.success(prices);
    }

    /**
     * 根据工序名称获取单价（Phase 5新增）
     */
    @GetMapping("/process-price/{orderNo}/{processName}")
    public Result<?> getUnitPriceByProcess(
            @PathVariable String orderNo,
            @PathVariable String processName) {
        Map<String, Object> priceInfo = skuService.getUnitPriceByProcess(orderNo, processName);
        return Result.success(priceInfo);
    }

    /**
     * 计算订单总工价（Phase 5新增）
     */
    @GetMapping("/order-total-cost/{orderNo}")
    public Result<?> calculateOrderTotalCost(@PathVariable String orderNo) {
        Map<String, Object> costInfo = skuService.calculateOrderTotalCost(orderNo);
        return Result.success(costInfo);
    }
}
